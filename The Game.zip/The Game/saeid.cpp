//
#include <string>
#include <fstream>
#include <ctime>
#include <cmath>
#include <iostream>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL2_gfx.h>
#include <SDL2/SDL_mixer.h>
using namespace std;

int SCREEN_WIDTH = 1245;
int SCREEN_HEIGHT = 720;

//The window we'll be rendering to
SDL_Window* gWindow = NULL;
SDL_Renderer* renderer= NULL;
TTF_Font *gFont = NULL;
Mix_Music *music = NULL;
//The surface contained by the window

SDL_Surface* gTempSurface = NULL;
SDL_Texture* gTempTexture = NULL;
SDL_Texture* nameMenu = NULL;
SDL_Texture* brickPhoto100 = NULL;
SDL_Texture* brickPhoto75 = NULL;
SDL_Texture* brickPhoto50 = NULL;
SDL_Texture* brickPhoto25 = NULL;
SDL_Texture* brickPhoto0 = NULL;


//The image we will load and show on the screen
SDL_Surface* gHelloWorld = NULL;

const int length=140,
width=50,
dist=15;

//////////////////////////funcs/////////////////////////////


void randomCol(int &r,int &g,int &b){// creates a hsl bright color then gives rgb

    short int deg = rand()%360 ;
    float x = 1-abs(  deg / 60.0  - deg/60 + (deg/60)%2-1);
    if(deg >= 300){
        r = 255;
        g = 0;
        b = x*255;
        }
    else if(deg >= 240){
        r = x*255;
        g = 0;
        b = 255;
        }
    else if(deg >= 180){
        r = 0;
        g = x*255;
        b = 255;
        }
    else if(deg >= 120){
        r = 0;
        g = 255;
        b = x*255;
        }
    else if(deg >= 60){
        r = x*255;
        g = 255;
        b = 0;
        }
    else {
        r = 255;
        g = x*255;
        b = 0;
        }

}
int randomCol(int &hue){


    int r,g,b;


    short int deg ;
    deg = hue;
    float x = 1-abs(  deg / 60.0  - deg/60 + (deg/60)%2 -1);
    if(deg >= 300){
        r = 255;
        g = 0;
        b = x*255;
        }
    else if(deg >= 240){
        r = x*255;
        g = 0;
        b = 255;
        }
    else if(deg >= 180){
        r = 0;
        g = x*255;
        b = 255;
        }
    else if(deg >= 120){
        r = 0;
        g = 255;
        b = x*255;
        }
    else if(deg >= 60){
        r = x*255;
        g = 255;
        b = 0;
        }
    else {
        r = 255;
        g = x*255;
        b = 0;
        }
        return 0xff*256*256*256 + b*256*256 + g*256 + r;
}
//void shift(brickclass[10][8], int*);

//////////////////////////classes///////////////////////////

class brickclass{

public:
    int xc, yc;
    //bool exist=0;
    int strength,first_strength=0;
    SDL_Rect r={xc-168/2,yc-78/2,168,78};
    void render(){

        r={xc-168/2,yc-78/2,168,78};

        //stringColor(renderer,xc-length/2,yc-width/2,&to_string(strength)[0],0xffffffff);
        if(strength){
            if(strength==first_strength){ //boxColor(renderer,xc-length/2 ,yc-width/2, xc+length/2, yc+width/2,0xffff0000);
            SDL_RenderCopy(renderer,brickPhoto100,NULL,&r);

            }else if(strength>= 3 / 4.0 *first_strength){ //boxColor(renderer,xc-length/2 ,yc-width/2, xc+length/2, yc+width/2,0xffff0000);
            SDL_RenderCopy(renderer,brickPhoto75,NULL,&r);

            }else if(strength>=  0.5 *first_strength){ //boxColor(renderer,xc-length/2 ,yc-width/2, xc+length/2, yc+width/2,0xffff0000);
            SDL_RenderCopy(renderer,brickPhoto50,NULL,&r);

            }else if(strength>=  1 / 4.0 *first_strength){ //boxColor(renderer,xc-length/2 ,yc-width/2, xc+length/2, yc+width/2,0xffff0000);
            SDL_RenderCopy(renderer,brickPhoto25,NULL,&r);
            }else { //boxColor(renderer,xc-length/2 ,yc-width/2, xc+length/2, yc+width/2,0xffff0000);
            SDL_RenderCopy(renderer,brickPhoto0,NULL,&r);
            }
        }
    }

};

class platformclass{

public:
    int xc;
    int yc;
    int vx=4;
    int length=235;
    int width=10;
    SDL_Texture* aks = NULL;
    SDL_Rect temp;

    platformclass(){

    aks = IMG_LoadTexture(renderer,"platdesign.png");
    SDL_SetTextureBlendMode(aks,SDL_BLENDMODE_BLEND);


    SDL_SetTextureColorMod(aks,0,184,255);
    }


    bool update(SDL_Event *e){


        //check platform to be in screen
        if(xc>SCREEN_WIDTH+length/2) xc=-length/2;
        else if(xc<-length/2) xc=SCREEN_WIDTH+length/2;
        SDL_PollEvent(e);
        if(e!= NULL && e->type==SDL_KEYDOWN)
        {
            switch(e->key.keysym.sym)
            {
                case SDLK_ESCAPE:
                  return false;
                  break;
                case SDLK_RIGHT:
                  xc+=vx;
                  return true;
                  break;
                case SDLK_LEFT:
                  xc-=vx;
                  return true;
                  break;
            }
        }

        return true;
    }
    bool multiplater_update(const Uint8* keys,int player){

        //check platform to be in screen
        if(xc>SCREEN_WIDTH+length/2) xc=-length/2;
        else if(xc<-length/2) xc=SCREEN_WIDTH+length/2;

        if(keys[SDL_GetScancodeFromKey(SDLK_ESCAPE)])
            return false;
        if(keys[SDL_GetScancodeFromKey(SDLK_RIGHT)] && player==1){
            xc+=vx;
            return true;
        }

        if(keys[SDL_GetScancodeFromKey(SDLK_LEFT)] && player==1){
            xc-=vx;
            return true;
        }

        if(keys[SDL_GetScancodeFromKey(SDLK_KP_6)] && player==2){
            xc+=vx;
            return true;
        }

        if(keys[SDL_GetScancodeFromKey(SDLK_KP_4)] && player==2){
            xc-=vx;
            return true;
        }

    }

    void render(){

        temp = {xc-length/2-70,yc-width/2-16,372,112};
        //boxRGBA(renderer,xc-length/2 ,yc-width/2, xc+length/2, yc+width/2,255,255,0,255);
        SDL_RenderCopy(renderer,aks,NULL,&temp);
    }
};

class ball{
public:
    int damage;
    float xc=600,yc=800;
    int angle;
    float vx,vy;
    float v=2;
    int R=10;
    int hue =0;


    void setAng(int start, int end){  // chooses angle between strat and end

        angle = (rand()%(end - start)) + start;
        cout<< angle;
        vx = v*cos( angle / 180.0 * 3.1415);
        vy = -v*sin( angle / 180.0 * 3.1415);
    }

    void setAng(int angle){
        vx = v*cos( angle / 180.0* 3.1415);
        vy = -v*sin( angle / 180.0 * 3.1415);
    }




    bool chckCollid(platformclass platform){

        if(xc>platform.xc-platform.length/2 && xc<platform.xc+platform.length/2 && yc>platform.yc-R-platform.width/2 && yc<platform.yc-R)
            {vy*=-1;  return true; }


        else if(  (xc - (platform.xc - platform.length/2)) * (xc - (platform.xc - platform.length/2))+
            (yc - (platform.yc - platform.width/2)) * (yc - (platform.yc - platform.width/2)) <=  (R * R)  )
                {setAng(90,180);  return true;}


        else if (  (xc - (platform.xc + platform.length/2)) * (xc - (platform.xc + platform.length/2))+
            (yc - (platform.yc - platform.width/2)) * (yc - (platform.yc - platform.width/2)) <= (R * R)  )
                {setAng(0,90);  return true;}
        return false;

    }



    bool chckCollid(brickclass brick){


        if(yc<R+brick.yc+width/2 && xc<brick.xc+length/2 &&
            xc>brick.xc-length/2 && brick.strength && yc>brick.yc-width/2-R)

        {
            vy*=-1;



//            int tmp;
//            tmp=damage;
//            damage-=brick.strength;
//            brick.strength-=tmp;
//            if(brick.strength<=0) brick.exist=false;
//            if(damage<=0)
//                    {
//                    level+=1;
//                    damage=level;
//                }
            return true;
        }

        else if(xc> brick.xc-length/2-R && yc < brick.yc+width/2 &&
                yc>brick.yc-width/2 && xc< R+brick.xc+length/2 && brick.strength)
        {
            vx*=-1;

//            cout <<  brick.xc-length/2-R  << " < " <<  xc << " < " << R+brick.xc+length/2<< endl
//
//            <<  ;
//            tmp=damage;
//            damage-=brick.strength;
//            brick.strength-=tmp;
//            if(brick.strength<=0) brick.exist=false;
//            if(damage<=0)
//                {
//                    level+=1;
//                    damage=level;
//                }

            return true;


        } else if(brick.strength) {  //a^2 + b^2 = c^2

            if(  (xc - (brick.xc - length/2)) * (xc - (brick.xc - length/2))+
            (yc - (brick.yc - width/2)) * (yc - (brick.yc - width/2)) <=  (R * R))
                {setAng(90,180);  return true;}


            else if (  (xc - (brick.xc + length/2)) * (xc - (brick.xc + length/2))+
            (yc - (brick.yc - width/2)) * (yc - (brick.yc - width/2)) <= (R * R))
                {setAng(0,90);  return true;}


            else if (  (xc - (brick.xc + length/2)) * (xc - (brick.xc + length/2))+
            (yc - (brick.yc + width/2)) * (yc - (brick.yc + width/2)) <=  (R * R))
                {setAng(270,360);  return true;}


            else if (  (xc - (brick.xc - length/2)) * (xc - (brick.xc - length/2))+
            (yc - (brick.yc + width/2)) * (yc - (brick.yc + width/2)) <= (R * R))
                {setAng(180,270);  return true;}
        }
        return false;




    }
    void update(brickclass brick[10][8],platformclass platform){

        xc += vx;
        yc += vy;
        //check brick
        for(int i=0 ;i<10 ;i++){
            for(int j=0 ;j<8 ;j++){

                if( chckCollid(brick[i][j] ))
                {
                    brick[i][j].strength--;
                    Mix_PlayMusic(music, 1);
                    xc += 2*vx;
                    yc += 2*vy;
                    //cout << i << " " << j<< endl;
                }

            }
        }
        if( chckCollid(platform))
        {
            Mix_PlayMusic(music, 1);
            xc += 2*vx;
            yc += 2*vy;
        }
        //check Plat
        //check collision of ball and walls
        if(xc>SCREEN_WIDTH-R || xc<R) vx*=-1;
        if(yc<R) vy*=-1;

    }
    void render(){

        hue++;
        if(hue>=360) hue=0;
        //cout << hue<< endl;
        filledCircleColor(renderer,xc,yc,R,randomCol(hue));

        //SDL_RenderPresent(renderer);


        //boxRGBA(renderer,xc-length/2 ,yc-width/2, xc+length/2, yc+width/2,255,255,0,255);

    }




};
class lableBox{
public:

    SDL_Texture* aks = NULL;
    SDL_Texture* matn = NULL;
    unsigned short int x,y,w=680,h=300;
    //string text;
    int recordCount;
    int *lives, *levels, *scores;


    lableBox(int x_,int y_, string name,string saves,bool isNew){

        //aks = IMG_LoadTexture(renderer, "lableBox.bmp");  //akse box
        x= x_ - w/2;
        y= y_ - h/2;

        if(isNew){



        }else{

        //////////////////////////getting record from file string/////////////////////////

        //name = "@"+name+"<";
        int record_count_Position = saves.find(name)+name.length()+2;  // +4  is for <c> in the save file
        recordCount =(int) saves[record_count_Position]-'0';


        lives = new int[recordCount];
        levels = new int[recordCount];
        scores = new int[recordCount];


        int lastChecked_index = record_count_Position;
        for(int i=0; i<recordCount ; i++){                                     //inaro lazem nist bexuni


            string temp;

            //cout<<saves.find("<lev>",lastChecked_index)+5 << endl << saves.find("</lev>",lastChecked_index)<< endl;
            temp = saves.substr(saves.find("<lev>",lastChecked_index)+5,
                                saves.find("</lev>",lastChecked_index)-saves.find("<lev>",lastChecked_index)-5);
            //cout<< temp;
            levels[i] = stoi(temp);

            temp = saves.substr(saves.find("<s>",lastChecked_index)+3,
                                saves.find("</s>",lastChecked_index)-saves.find("<s>",lastChecked_index)-3);
            scores[i] =stoi(temp);

            temp = saves.substr(saves.find("<liv>",lastChecked_index)+5,
                                saves.find("</liv>",lastChecked_index)-saves.find("<liv>",lastChecked_index)-5);
            //cout << (temp);
            lives[i] =stoi(temp);


            lastChecked_index = saves.find("</liv>",lastChecked_index)+5;


        }}
        /////////////////////////loading aks to main texture////////////////////
        aks = SDL_CreateTexture(renderer,SDL_PIXELFORMAT_RGB888,SDL_TEXTUREACCESS_TARGET,w,h);
        SDL_Texture* temp = IMG_LoadTexture(renderer,"butt.bmp");
        SDL_SetRenderTarget(renderer,aks);
        SDL_RenderCopy(renderer,temp,NULL,NULL);
        //SDL_RenderPresent(renderer);
        //cout<<SDL_GetError()<<"beep";

        //SDL_RenderCopy(renderer,temp,NULL,NULL);
        //SDL_SetRenderTarget(renderer,NULL);
        //SDL_RenderCopy(renderer,aks,NULL,NULL);
        //SDL_RenderPresent(renderer);
        //free(temp);



        ///////////////////////////creating text////////////////////////

        ///////creating string////////
        string live="Lives    ",sco="Score   ",leve="Level    ";
        if (isNew){
            leve = "No record!";
            sco ="";
            live="";
        }else{


            for(int i = 0; i<recordCount;i++){
                live += to_string(lives[i]) + "    ";
                sco +=  to_string(scores[i]) + "    ";
                leve +=  to_string(levels[i]) + "    ";

            }

        }

        ////////creating texture//////////
        SDL_Color col ={255,255,255,255};

        gTempSurface = TTF_RenderText_Solid( gFont, &leve[0], col);  // dorost kardan matn ba font ba ttf
        matn = SDL_CreateTextureFromSurface( renderer, gTempSurface );

        ///////////////////render copy for level/////////////////////
        int tempW,tempH;
        SDL_QueryTexture(matn,NULL,NULL,&tempW,&tempH);
        SDL_Rect temp2={ 20 , 40, tempW, tempH };   //tanzim mokhtasat matn baraye copy
        SDL_RenderCopy(renderer,matn,NULL,&temp2);

        ///////////////////render copy for score/////////////////////


        gTempSurface = TTF_RenderText_Solid( gFont,&sco[0], col );  // dorost kardan matn ba font ba ttf
        matn = SDL_CreateTextureFromSurface( renderer, gTempSurface );

        SDL_QueryTexture(matn,NULL,NULL,&tempW,&tempH);
        temp2={ 20 , 74, tempW, tempH };   //tanzim mokhtasat matn baraye copy
        SDL_RenderCopy(renderer,matn,NULL,&temp2);


        ///////////////////render copy for life/////////////////////

        gTempSurface = TTF_RenderText_Solid( gFont,&live[0], col );  // dorost kardan matn ba font ba ttf
        matn = SDL_CreateTextureFromSurface( renderer, gTempSurface );

        SDL_QueryTexture(matn,NULL,NULL,&tempW,&tempH);
        temp2={ 20 , 108, tempW, tempH };   //tanzim mokhtasat matn baraye copy
        SDL_RenderCopy(renderer,matn,NULL,&temp2);



        free(gTempSurface);
        SDL_SetRenderTarget(renderer,NULL);
    }

    void render(){
        SDL_Rect temp={x,y,w,h};
        SDL_RenderCopy(renderer,aks,NULL,&temp);

    }




};

class textBox{
public:

    SDL_Texture* aks = NULL;
    SDL_Texture* matn = NULL;
    unsigned short int x,y,w=400,h=104 ,aks_w=400,aks_h=104;


    char text[20];         //matn dakhele box
    int currentTextIndex=0;       //index baraye neveshtan char


    textBox(){
        aks = IMG_LoadTexture(renderer, "textBox.png");  //akse box
        SDL_SetTextureBlendMode(aks,SDL_BLENDMODE_ADD);
        SDL_SetTextureBlendMode(matn,SDL_BLENDMODE_ADD);
        x= SCREEN_WIDTH/2 - aks_w/2;
        y= SCREEN_HEIGHT/2 - aks_h/2;
        for(int i =0;i<20;i++)
            text[i]='\0';

//IMG_LoadTexture()

    }
    void render(){
        SDL_Color col ={255,255,255,255};
        gTempSurface = TTF_RenderText_Solid( gFont,text, col );
        matn = SDL_CreateTextureFromSurface( renderer, gTempSurface );   // dorost kardan matn ba font ba ttf
        free(gTempSurface);
        SDL_Rect tempRect={x,y,aks_w,aks_h};  // tanzim mokhtasat aks
        //boxColor(renderer,0,0,100,100,0xffffffff);
        SDL_RenderCopy(renderer,aks,NULL,&tempRect);         // copy kardan aks background ruuye target renderr
        int tempW,tempH;
        SDL_QueryTexture(matn,NULL,NULL,&tempW,&tempH);
        SDL_Rect temp2={x+ w/2 - (tempW)/2 , y+h/2-10, tempW, tempH };   //tanzim mokhtasat matn
        SDL_RenderCopy(renderer,matn,NULL,&temp2);


    }
    void addText(SDL_Event e){

        if( (e.key.keysym.sym == SDLK_BACKSPACE)){

            if(currentTextIndex!=0){
                currentTextIndex--;
                text[currentTextIndex] = '\0';
                render();
                SDL_RenderPresent(renderer);
            }


        }else if((currentTextIndex < 19)&& ((e.key.keysym.sym >='a' && e.key.keysym.sym <='z') ||
                                                                                (e.key.keysym.sym >='A' && e.key.keysym.sym <='Z')||
                                                                                (e.key.keysym.sym >='0' && e.key.keysym.sym <='9') ||
                                                                                e.key.keysym.sym ==' ') ){
            text[currentTextIndex] =(char) e.key.keysym.sym;
            render();
            SDL_RenderPresent(renderer);
            currentTextIndex ++;


        }
    }



};
class Button{
public:

    SDL_Texture* aks = NULL;
    SDL_Texture* aks_inverted = NULL;
    SDL_Texture* matn = NULL;
    SDL_Texture* temp= NULL;
    unsigned short int x,y,w=318,h=124;
    int tempW,tempH;
    SDL_Rect temp2;
    bool clicked=0;


    char *text;         //matn dakhele box
    int currentTextIndex=0;       //index baraye neveshtan char


    Button(char* button_text,int x_,int y_){


        //////////////dorost kardan texture matn////////////
        SDL_Color col ={255,255,255,255};
        gTempSurface = TTF_RenderText_Solid( gFont,button_text, col );  // dorost kardan matn ba font ba ttf
        //if(gTempSurface== nullptr)cout<<",mmm";
        matn = SDL_CreateTextureFromSurface( renderer, gTempSurface );
        SDL_SetTextureBlendMode(matn,SDL_BLENDMODE_ADD);
        free(gTempSurface);


        SDL_QueryTexture(matn,NULL,NULL,&tempW,&tempH);
        //temp2={ w/2 - (tempW)/2 , h/2-16, tempW, tempH };   //tanzim mokhtasat matn baraye copy

        /////////////////////load kardane aks ha//////////////////////

        //aks =   SDL_CreateTexture(renderer,SDL_PIXELFORMAT_RGBA8888,SDL_TEXTUREACCESS_TARGET,w,h);
        //SDL_SetRenderTarget(renderer,aks);
        //SDL_SetRenderDrawColor(renderer,0,0,0,0);
        //SDL_RenderClear(renderer);
        //temp = IMG_LoadTexture(renderer, "butt.png");  //akse button
        //SDL_SetTextureBlendMode(temp,SDL_BLENDMODE_BLEND);
        //SDL_SetTextureBlendMode(aks,SDL_BLENDMODE_BLEND);
        //SDL_RenderCopy(renderer,temp,NULL,NULL);
        //SDL_RenderCopy(renderer,matn,NULL,&temp2);   //copy matn rooye aks


        //temp2 = {318/2 - (tempW)/2 , 124/2-16, tempW, tempH};
//        aks_inverted = SDL_CreateTexture(renderer,SDL_PIXELFORMAT_RGBA8888,SDL_TEXTUREACCESS_TARGET,318,124);
//        SDL_SetRenderTarget(renderer,aks_inverted);

        temp = IMG_LoadTexture(renderer, "butt_inv.png");  //akse button
        SDL_SetTextureBlendMode(temp,SDL_BLENDMODE_ADD);
       // SDL_SetTextureBlendMode(aks_inverted,SDL_BLENDMODE_ADD);
       // SDL_SetRenderTarget(renderer,aks_inverted);
        //SDL_RenderCopy(renderer,temp,NULL,NULL);
        //SDL_SetTextureColorMod(matn,0,0,0);
        //SDL_RenderCopy(renderer,matn,NULL,&temp2);   //copy matn rooye aks

        //SDL_SetRenderTarget(renderer,NULL);


        //SDL_DestroyTexture(temp);
        //x= x_ - w/2;
        //y= y_ - h/2;
        x= x_ ;
        y= y_ ;
        text = button_text;


        ///////////////ezafe kardane matne button//////////////


    }
    void render(bool darken){
        if(0){

            SDL_Rect tempRect={x-w/2,y-h/2,w,h};  // tanzim mokhtasat aks
            int r,g,b;
            randomCol(r,g,b);

            if(!darken)SDL_SetTextureColorMod(aks_inverted,r,g,b);
            else SDL_SetTextureColorMod(aks_inverted,r/2,g/2,b/2);
            SDL_RenderCopy(renderer,aks,NULL,&tempRect);

        }else{

            temp2 = {x - (tempW)/2 , y-16, tempW, tempH};

            SDL_Rect tempRect={x-318/2,y-124/2,318,124};  // tanzim mokhtasat aks
            int r,g,b;
            randomCol(r,g,b);
            if(/*!darken*/1)SDL_SetTextureColorMod(temp,r,g,b);
            SDL_SetTextureColorMod(matn,r,g,b);
            SDL_RenderCopy(renderer,temp,NULL,&tempRect);
            SDL_RenderCopy(renderer,matn,NULL,&temp2);   //copy matn rooye aks

        }


    }




};


void shift(brickclass brick[10][8], int &level){
    level++;
    for(int i = 10; i>0 ; i--){

        for(int j = 0; j<8 ; j++){

            if(i!=1){

                    brick[i-1][j].strength = brick[i-2][j].strength;
                    brick[i-1][j].first_strength = brick[i-2][j].first_strength;
            }

            else {

                    brick[i-1][j].first_strength = rand()%level;
                    brick[i-1][j].strength = brick[i-1][j].first_strength;
            }


        }

    }

}


//Starts up SDL and creates window
bool init();

//Loads media
bool loadMedia();

//Frees media and shuts down SDL
void close();


/**
*    the     main
*
*
*/
int main( int argc, char* args[] )
{

////////////////save file init//////////////
    fstream out;
    out.open("saves.txt", ios_base::in);
    out.seekg(0, std::ios::end);
    size_t size = out.tellg();
                                        //+++++ MOHEM ++++
    string saves(size, ' ');              //darmorede ina natars   hamasho copy paste kardam khodamam nemidunm chie
    //out.ignore();                       //fgt bedun ke file ro miare tu ye string
    out.seekg(0);
    out.read(&saves[0],size);
    //cout<<saves;
    out.close();
//////////////////////////////////////////
	bool quit = false;
	SDL_Event e;
	init();
	IMG_Init(IMG_INIT_PNG);
	Mix_Init(MIX_INIT_MOD);
	Mix_OpenAudio(MIX_DEFAULT_FREQUENCY,MIX_DEFAULT_FORMAT, 2, 1024);

    music = Mix_LoadMUS("hit.wav");
///////////////font init///////////////
	TTF_Init();
	gFont = TTF_OpenFont( "pixel.ttf", 28 );
/////////////////////////////////////////
////////////////backgroudn load///////////
    SDL_Texture* background;
    background = IMG_LoadTexture(renderer, "xx1.jpg");
    SDL_RenderCopy(renderer,background,NULL,NULL);
/////////////////////first name text box//////////////

    textBox* name = new textBox();
    name->render();
    SDL_RenderPresent(renderer);
///////////////////////////////////////////////////
    brickPhoto100 = IMG_LoadTexture(renderer, "100.png");
    SDL_SetTextureColorMod(brickPhoto100,0,184,255);
    brickPhoto75 = IMG_LoadTexture(renderer, "75.png");
    SDL_SetTextureColorMod(brickPhoto75,255,108,0);
    brickPhoto50 = IMG_LoadTexture(renderer, "50.png");
    SDL_SetTextureColorMod(brickPhoto50,255,108,0);
    brickPhoto25 = IMG_LoadTexture(renderer, "25.png");
    SDL_SetTextureColorMod(brickPhoto25,255,108,0);
    brickPhoto0 = IMG_LoadTexture(renderer, "0.png");
    SDL_SetTextureColorMod(brickPhoto0,213,19,0);
        //Update the surface


    while( !quit )
    {
        //Handle events on queue
        while( SDL_PollEvent( &e ) != 0 )
        {
            //User requests quit
            if( e.type == SDL_QUIT )
            {
                quit = true;
            }else if(e.type == SDL_KEYDOWN && e.key.keysym.sym == SDLK_RETURN)
            {
                string Name = name->text;
                Name = "@" +Name+ "<";
                //cout << Name << "ll";


                unsigned int namePos= saves.find(Name);    //position of the name in the text
                bool isNew = (namePos == string::npos);


//                if(namePos == string::npos){  //agar esm dar file mojod nabashad
//
//                    isNew = 1;
//                }
//                else{
//                    isNew = 0;
//
//                }

                SDL_RenderCopy(renderer,background,NULL,NULL);

                //////////////////////buttons////////////////////////////

                Button* newG = new Button("New Game",850,600);  //new game butto
                newG->render(0);

                Button* load = new Button("Load",350,600);  //continue button
                if(!isNew)load->render(!isNew);

                //SDL_RenderPresent(renderer);


                /////////////////lable box/////////////////////////////////

                lableBox* my= new lableBox(600,350,Name,saves,isNew);
                my->render();
                SDL_RenderPresent(renderer);


                ////////////////button control////////////////////////////


                bool newGflag=0,loadflag=0;
                while(!(newGflag || loadflag)){


                    while(e.type != SDL_MOUSEBUTTONDOWN)
                        SDL_PollEvent(&e);

                    //cout << newG->x - newG->w/2 << " < " << e.button.x << " < " << newG->x + newG->w/2 << endl;
                    //cout << newG->y - newG->h/2 << " < " << e.button.y << " < " << newG->y + newG->h/2 << endl;
                    //if(e.type == SDL_MOUSEBUTTONDOWN){
                    if((e.button.x < newG->x + newG->w/2)  &&  (e.button.x > newG->x - newG->w/2)  &&
                        (e.button.y < newG->y + newG->h/2)  &&  (e.button.y > newG->y - newG->h/2))
                        newG ->clicked = 1;

                    else if(e.button.x < load->x + load->w/2  &&  e.button.x > load->x - load->w/2  &&
                            e.button.y < load->y + load->h/2  &&  e.button.y > load->y - load->h/2)
                        load ->clicked = 1;

                    SDL_RenderCopy(renderer,background,NULL,NULL);
                    my->render();
                    newG->render(0);
                    if(!isNew)load->render(0);
                    SDL_RenderPresent(renderer);
                    //} else if(0);// for handling escape button currently empty
                    while(e.type != SDL_MOUSEBUTTONUP)
                        SDL_PollEvent(&e);

                    if(e.button.x < newG->x + newG->w/2  &&  e.button.x > newG->x - newG->w/2  &&
                        e.button.y < newG->y + newG->h/2  &&  e.button.y > newG->y - newG->h/2)
                        newGflag =1;

                    else if(e.button.x < load->x + load->w/2  &&  e.button.x > load->x - load->w/2  &&
                            e.button.y < load->y + load->h/2  &&  e.button.y > load->y - load->h/2 && !isNew)
                        loadflag = 1;

                }
                fstream bricks;
                bricks.open("brick.txt",ios_base::in);
                bricks.seekg(0, std::ios::end);
                size_t size = bricks.tellg();
                string brickData(size, ' ');              //this part reads brick.txt file
                //out.ignore();                           //and puts the whole file into one string
                bricks.seekg(0);
                bricks.read(&brickData[0],size);
                bricks.close();


                int level,lives,score,damage;
                brickclass brick[10][8];
                //brickclass bb[1][1];

                if(newGflag){
                    level=0;
                    lives=0;
                    score=0;
                    damage=0;

                    for(int i = 0;i<10;i++)
                        for(int j=0;j<8;j++){
                            brick[i][j].first_strength=0;
                            brick[i][j].strength=0;
                        }



                }
                else if(loadflag){
                    level = my->levels[0];
                    lives = my->lives[0];
                    score = my->scores[0];

                    int currentIndex=brickData.find('>',brickData.find(Name));

                    damage = stoi(brickData.substr(currentIndex+1,brickData.find('/',currentIndex)-currentIndex-1));
                    //cout << damage;
                    currentIndex=brickData.find('/',brickData.find(Name));
                    //cout<< brickData;
                    for(int i = 0;i<10;i++)
                        for(int j=0;j<8;j++){
                            //cout << brickData.substr(currentIndex+1 ,brickData.find('/', currentIndex+1) - currentIndex-1);
                            brick[i][j].strength= stoi(brickData.substr(currentIndex+1 ,
                                                                         brickData.find('-', currentIndex+1) - currentIndex-1));

                            currentIndex = brickData.find('-', currentIndex+1);
                            brick[i][j].first_strength= stoi(brickData.substr(currentIndex+1 ,
                                                                         brickData.find('/', currentIndex+1) - currentIndex-1));

                            currentIndex = brickData.find('/', currentIndex+1);

                        }


                }
                background = IMG_LoadTexture(renderer, "back4.jpg");
                SDL_RenderCopy(renderer,background,NULL,NULL);
                //SDL_RenderClear(renderer);
                for(int i=0;i<10;i++)
                for(int j=0;j<8;j++){

//                    if(brick[i][j].strength !=0){
//                        boxColor(renderer,j*(length+dist) ,i*(width+dist),j*(length+dist)+length,i*(width+dist)+width,0xffff0000);
//                        brick[i][j].exist =1;
//                    }
                    //if(brick[i][j].strength  > 0) brick[i][j].exist =1;
                    brick[i][j].xc = j*(length+dist)+ length/2+10;
                    brick[i][j].yc = i*(width+dist)+ width/2+10;
                    brick[i][j].render();
                    //stringRGBA(renderer,j*(length+dist),i*(width+dist),&to_string(brick[i][j].exist)[0],255,255,255,255);

                }
                SDL_RenderPresent(renderer);


                bool lost=0,save=0;
                bool multiplayer=true;;
                int player;
                const Uint8* keys = SDL_GetKeyboardState(NULL);


                ball Ball;
                platformclass platform;
                ball Ball_;
                platformclass platform_;


                bool jump=0;
                bool arrow=0;
                int fireAng =90;

                while(!jump){

                    arrow=false;
                    SDL_PumpEvents();
                    if(keys[SDL_GetScancodeFromKey(SDLK_w)]) { fireAng++; arrow=true;}
                    else if(keys[SDL_GetScancodeFromKey(SDLK_s)]) { fireAng--; arrow=true;}
                    else if(keys[SDL_GetScancodeFromKey(SDLK_SPACE)]) { jump=true; arrow=true;}
                    else if(keys[SDL_GetScancodeFromKey(SDLK_y)]){

                            shift(brick,level);
                            //SDL_SetRenderDrawColor(renderer,0,0,0,0);
                            //SDL_RenderClear(renderer);
                            SDL_RenderCopy(renderer,background,NULL,NULL);
                            for(int i=0;i<10;i++)
                            for(int j=0;j<8;j++){

                                brick[i][j].render();
                                    }
                    }

                            if(arrow){
                            aalineColor(renderer,SCREEN_WIDTH/2,SCREEN_HEIGHT,SCREEN_WIDTH/2+500*cos(fireAng*3.14/180),SCREEN_HEIGHT-500*sin(fireAng*3.14/180),0xffffffff);
                            SDL_RenderPresent(renderer);
                            }

                }

                platform.yc=700;
                platform.xc=400;

                Ball.yc=platform.yc-platform.width/2-Ball.R;
                Ball.xc=platform.xc;



                //second player
                platform_.yc=700;
                platform_.xc=700;

                Ball_.yc=platform_.yc-platform_.width/2-Ball_.R;
                Ball_.xc=platform_.xc;



                Ball.setAng(fireAng);
                if(multiplayer) Ball_.setAng(fireAng);
                while(!lost && !save){//each frame happens here
                    //SDL_Delay(10);

                    //platform.update(); returns false if ESCAPE key is pressed

                    //SDL_PumpEvents();
                    platform.multiplater_update(keys,1);
                    Ball.update(brick,platform);

                    if(multiplayer){

                        platform_.multiplater_update(keys,2);
                        Ball_.update(brick,platform_);
                    }
                    //if(!platform.update()) break;
                    //SDL_SetRenderDrawColor(renderer,0,0,0,0);
                    //SDL_RenderClear(renderer);
                    SDL_RenderCopy(renderer,background,NULL,NULL);


                    for(int i=0;i<10;i++)
                    for(int j=0;j<8;j++){

                       brick[i][j].render();
                        //stringRGBA(renderer,j*(length+dist),i*(width+dist),&to_string(brick[i][j].strength)[0],255,255,255,255);

                    }

                    Ball.render();
                    platform.render();

                    if(multiplayer){
                        Ball_.render();
                        platform_.render();
                    }

                    SDL_RenderPresent(renderer);

                    SDL_PollEvent(&e);
                    if(e.type == SDL_KEYUP && e.key.keysym.sym== SDLK_ESCAPE){
                        save =1;}
                    else if(e.type == SDL_KEYDOWN && e.key.keysym.sym== SDLK_y)
                        {shift(brick,level);}
                    else if(e.type == SDL_KEYDOWN && e.key.keysym.sym== SDLK_w)
                        {Ball.vy = -abs(Ball.vy);}
                    else if(e.type == SDL_KEYDOWN && e.key.keysym.sym== SDLK_d)
                        {Ball.vx = abs(Ball.vx);}
                    else if(e.type == SDL_KEYDOWN && e.key.keysym.sym== SDLK_s)
                        {Ball.vy = abs(Ball.vy);}
                    else if(e.type == SDL_KEYDOWN && e.key.keysym.sym== SDLK_a)
                        {Ball.vx = -abs(Ball.vx);}


//                    for(int j=0;j<8;j++){
//                        if(brick[9][j].strength != 0)
//                            lost = 1;
                            //cout << "jjj";

                    //}






                }

                if(save){  //saving the brick data

                    string::size_type index = brickData.find(Name);

                    if(index == string::npos){  //saving for new user
                        brickData += "\n" + Name + "d>" + to_string(damage);


                        for(int i=0;i<10;i++)
                        for(int j=0; j<8;j++){

                            brickData += "/" + to_string(brick[i][j].strength) + "-" + to_string(brick[i][j].first_strength) ;

                        }
                        brickData += "/" ;

                        //cout<< brickData;


                    }else{     //saving for old user


                        string append = to_string(damage);
                        for(int i=0;i<10;i++)
                        for(int j=0; j<8;j++){

                            append += "/" + to_string(brick[i][j].strength) + "-" + to_string(brick[i][j].first_strength) ;

                        }
                        append += "/" ;
                        int replaceBegin = brickData.find( ">", brickData.find(Name))+1;
                        int replaceEnd =    brickData.find( '\n', brickData.find(Name))-1;
                        brickData.replace( replaceBegin , replaceEnd - replaceBegin +1 , append );
                    }
                    bricks.open("brick.txt",ios_base::out|ios_base::trunc);
                    bricks << brickData;
                    bricks.close();



                    if(!isNew){
                        string append = Name + "c>";
                        append += (my->recordCount == 5? "5" : to_string(my->recordCount+1)) + "</c>";

                        append += "<lev>" + to_string(level) + "</lev>"
                                    + "<s>" + to_string(score) + "</s>"
                                    + "<liv>" + to_string(lives) + "</liv>";

                        for(
                            int i = 0 ;
                            i < (my->recordCount == 5 ? 4 : my->recordCount)  ;
                            i++)

                                {
                            append += "\n" ;
                            append += "<lev>" + to_string(my->levels[i]) + "</lev>"
                                    + "<s>" + to_string(my->scores[i]) + "</s>"
                                    + "<liv>" + to_string(my->lives[i]) + "</liv>";
                        }
                        append += "%";
                        int replaceBegin = saves.find(Name);
                        int replaceEnd = saves.find('%', replaceBegin+1);// -2 is for @ and '\n'
                        saves.replace( replaceBegin , replaceEnd - replaceBegin +1 , append );
                    }else{
                        saves += "\n" + Name + "c>1</c>";


                        saves += "<lev>" + to_string(level) + "</lev>"
                                    + "<s>" + to_string(score) + "</s>"
                                    + "<liv>" + to_string(lives) + "</liv>%";


                    }

                    out.open("saves.txt",ios_base::out|ios_base::trunc);
                    out << saves;
                    out.close();
                }



            }
            else if(e.type == SDL_KEYDOWN){//filling the textbox
                SDL_RenderCopy(renderer,background,NULL,NULL);

                int r,g,b;
                randomCol(r,g,b);
                SDL_SetTextureColorMod(name->aks,r,g,b);  //range random baraye textbox

                name->addText(e);

            }
            //cout << name->text<<'.'<<endl;


        }

				//Apply the imag
	}

	//Free resources and close SDL
	close();

	return 0;
}


/**  ////////////////////
*    init func //////////
*    ////////////////////
*
*/

bool init()
{
    //Initialization flag
    bool success = true;

    //Initialize SDL
    if( SDL_Init( SDL_INIT_VIDEO ) < 0 )
    {
        printf( "SDL could not initialize! SDL_Error: %s\n", SDL_GetError() );
        success = false;
    }
    else
    {
        //Create window
        gWindow = SDL_CreateWindow( "SDL Tutorial", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN );
        if( gWindow == NULL )
        {
            printf( "Window could not be created! SDL_Error: %s\n", SDL_GetError() );
            success = false;
        }
        else
        {
            //Get window surface
            //gScreenSurface = SDL_GetWindowSurface( gWindow );
        }
        //SDL_SetWindowFullscreen(gWindow, SDL_WINDOW_FULLSCREEN_DESKTOP);
        //SDL_GetWindowSize(gWindow,&SCREEN_WIDTH,&SCREEN_HEIGHT);
        renderer = SDL_CreateRenderer(gWindow,-1,SDL_RENDERER_SOFTWARE);
    }

    return success;
}

/**  ////////////////////
*    media func /////////
*    ////////////////////
*
*/

bool loadMedia()
{
    //Loading success flag
    bool success = true;

    //Load splash image
    SDL_SetRenderTarget(renderer,gTempTexture);
    //gTempSurface = SDL_LoadBMP("content/car.bmp");
    gTempTexture = IMG_LoadTexture(renderer,"content/car.bmp");
    SDL_RenderCopy(renderer,gTempTexture,NULL,NULL);
    SDL_SetRenderDrawColor(renderer, 255, 255, 255,255);
    lineColor(renderer,100,100,200,200,0xff0000ff);

    //SDL_RenderDrawLine(renderer,100,110,200,210);
    rectangleColor(renderer,100,100,200,200,0xff0000ff);
    SDL_RenderPresent(renderer);


    return success;
}


/**  ////////////////////
*    close func /////////
*    ////////////////////
*
*/

void close()
{
    //Deallocate surface
    SDL_FreeSurface( gHelloWorld );
    gHelloWorld = NULL;
    SDL_FreeSurface( gTempSurface );
    gTempSurface = NULL;
    SDL_DestroyRenderer(renderer);
    renderer = NULL;
    //Destroy window
    SDL_DestroyWindow( gWindow );
    gWindow = NULL;
    //Mix_CloseAudio();
    Mix_Quit();
    IMG_Quit();
    //Quit SDL subsystems
    SDL_Quit();
    printf("done");
}






//using namespace std;
//
//double length=180,width=50,dist=10,a=length/2+dist,b=width/2+dist;
//bool quit=false,flag=true;
//int lives=3,level=1,tmp,i,j;
//double random_angle1,random_angle2;
//
//class brickclass {
//
//public:
//
//    int xc;
//    int yc;
//    bool exist;
//    int strength;
//
//
//    brickclass(){
//        exist=true;
//    }
//
//};
//
//class platformclass {
//
//public:
//    int xc=750;
//    int yc=800;
//    int vx=1;
//
//
//};
//
//class ballclass {
//
//public:
//
//    double xc=750;
//    double yc=775;
//    double vx=0.5;
//    double vy=0.5;
//    double v=vx*1.4142;
//    int R=20;
//    int damage=1;
//
//
//    void setAng(int start, int end){  // chooses angle between strat and end
//        int angle = rand()%(end - start) + start;
//        vx = 3*cos( angle / 180 * 3.1415);
//        vy = -3*sin( angle / 180 * 3.1415);
//    }
//
//
//};
//
//brickclass brick[8][13];
//platformclass platform;
//ballclass ball;
//
//void platform_collision()
//{
//    if(ball.xc>platform.xc-100 && ball.xc<platform.xc+100 && ball.yc>platform.yc-ball.R-5 && ball.yc<platform.yc-ball.R && flag)
//    {
//        ball.vy*=-1;
//        flag=false;
//        if(ball.vx>0 && ((ball.xc<platform.xc-50) || (ball.xc>platform.xc+50)))
//        {
//            random_angle1=double(rand()%80+5)*M_PI/(double)180;
//            ball.vx=ball.v*cos(random_angle1);
//            ball.vy=ball.v*sin(random_angle1);
//        }
//        else if(ball.vx<0 && ((ball.xc<platform.xc-50) || (ball.xc>platform.xc+50)))
//        {
//            random_angle2=double(rand()%80+95)*M_PI/(double)180;
//            ball.vx=ball.v*cos(random_angle2);
//            ball.vy=ball.v*sin(random_angle2);
//        }
//    }
//    if(ball.yc<platform.yc-ball.R-5) flag=true;
//}
//
//bool brick_collision(int i, int j)
//{
//            if(ball.yc<ball.R+brick[i][j].yc+width/2 && ball.xc<brick[i][j].xc+length/2 &&
//               ball.xc>brick[i][j].xc-length/2 && brick[i][j].exist && ball.yc>-ball.R+brick[i][j].yc-width/2)
//
//           {
//                ball.vy*=-1;
//                tmp=ball.damage;
//                ball.damage-=brick[i][j].strength;
//                brick[i][j].strength-=tmp;
//                if(brick[i][j].strength<=0) brick[i][j].exist=false;
//                if(ball.damage<=0)
//                    {
//                        level+=1;
//                        ball.damage=level;
//                    }
//                return true;
//           }
//
//           else if(ball.xc>-ball.R+brick[i][j].xc-length/2 && ball.yc<brick[i][j].yc+width/2 &&
//                   ball.yc>brick[i][j].yc-length/2 && ball.xc<ball.R+brick[i][j].xc+length/2 && brick[i][j].exist)
//           {
//                ball.vx*=-1;
//                tmp=ball.damage;
//                ball.damage-=brick[i][j].strength;
//                brick[i][j].strength-=tmp;
//                if(brick[i][j].strength<=0) brick[i][j].exist=false;
//                if(ball.damage<=0)
//                    {
//                        level+=1;
//                        ball.damage=level;
//                    }
//
//                return true;
//
//
//           } else {  //a^2 + b^2 = c^2
//
//                if(  (ball.xc - (brick[i][j].xc - length/2)) * (ball.xc - (brick[i][j].xc - length/2))+
//                (ball.yc - (brick[i][j].yc - width/2)) * (ball.yc - (brick[i][j].yc - width/2)) ==  ball.R * ball.R)
//                    {ball.setAng(90,180);  return true;}
//
//
//                else if (  (ball.xc - (brick[i][j].xc + length/2)) * (ball.xc - (brick[i][j].xc + length/2))+
//                (ball.yc - (brick[i][j].yc - width/2)) * (ball.yc - (brick[i][j].yc - width/2)) ==  ball.R * ball.R)
//                    {ball.setAng(0,90);  return true;}
//
//                else if (  (ball.xc - (brick[i][j].xc + length/2)) * (ball.xc - (brick[i][j].xc + length/2))+
//                (ball.yc - (brick[i][j].yc + width/2)) * (ball.yc + (brick[i][j].yc - width/2)) ==  ball.R * ball.R)
//                    {ball.setAng(270,360);  return true;}
//
//                else if (  (ball.xc - (brick[i][j].xc - length/2)) * (ball.xc - (brick[i][j].xc - length/2))+
//                (ball.yc - (brick[i][j].yc + width/2)) * (ball.yc - (brick[i][j].yc + width/2)) ==  ball.R * ball.R)
//                    {ball.setAng(180,270);  return true;}
//           }
//           return false;
//
//}
//
//
//int main( int argc, char * argv[] )
//{
//
//
//    //Initialization of SDL windows
//    Uint32 SDL_flags = SDL_INIT_VIDEO | SDL_INIT_TIMER ;
//    Uint32 WND_flags = SDL_WINDOW_SHOWN | SDL_WINDOW_FULLSCREEN_DESKTOP;//SDL_WINDOW_BORDERLESS ;
//    SDL_Window * m_window;
//    SDL_Renderer * m_renderer;
//    //Texture for loading image
//
//    int img_w, img_h;
//    SDL_Rect img_rect;
//
//
//    SDL_Init( SDL_flags );
//    SDL_CreateWindowAndRenderer( 1200, 800, WND_flags, &m_window, &m_renderer );
//    //Pass the focus to the drawing window
//    SDL_RaiseWindow(m_window);
//    //Get screen resolution
//    SDL_DisplayMode DM;
//    SDL_GetCurrentDisplayMode(0, &DM);
//    int W = DM.w;
//    int H = DM.h;
//    // Clear the window with a black background
//    SDL_SetRenderDrawColor( m_renderer, 0, 0, 0, 255 );
//    SDL_RenderClear( m_renderer );
//
//    // Show the window
//    SDL_RenderPresent( m_renderer );
//
//    srand(time(NULL));
//
//
//    //give random strength to bricks
//    for(j=0;j<13;j++)
//    {
//        for(int i=0;i<8;i++)
//        {
//           brick[i][j].strength= 20;
//           //rand()%(j+2);
//           if(brick[i][j].strength%3==0) brick[i][j].exist=false;
//        }
//    }
//
//
//
//    SDL_Event *e = new SDL_Event();
//    bool jump=0;
//    int fireAng =90;
//    while(!jump){
//
//        SDL_PollEvent(e);
//        if(e->type == SDL_KEYDOWN)
//            {
//                switch(e->key.keysym.sym){
//                    case SDLK_w:
//                        fireAng++;
//                    break;
//                    case SDLK_s:
//                        fireAng--;
//                    break;
//                    case SDLK_SPACE:
//                        jump = 1;
//                    break;
//
//
//                }
//
//                aalineColor(m_renderer,600,800,600+30*cos(fireAng*3.14/180),800-30*sin(fireAng*3.14/180),0xffffffff);
//                SDL_RenderPresent(m_renderer);
//            }
//
//    }
//
//    while(!quit)
//    {
//
//        //bricks
//        for(j=0;j<level;j++)
//        {
//            for(i=0;i<8;i++)
//            {
//
//              brick[i][j].xc=a;
//              brick[i][j].yc=b;
//
//              //check collision with all bricks and draw them
//             if(brick[i][j].exist) {
//                 boxRGBA(m_renderer,a-length/2,width/2+b,a+length/2,b-width/2,255,0,0,255);
//                 brick_collision(i,j);
//                 }
//             a=a+length+dist;
//            }
//             a=length/2+dist;
//             b=b+width+dist;
//        }
//        b=width/2+dist;
//
//
//
//
//    SDL_PollEvent(e);
//    //move platform
//    if(e->type==SDL_KEYDOWN)
//    {
//        switch(e->key.keysym.sym)
//        {
//        case SDLK_ESCAPE:
//            quit=true;
//            break;
//        case SDLK_RIGHT:
//            platform.xc+=platform.vx;
//            break;
//        case SDLK_LEFT:
//            platform.xc-=platform.vx;
//            break;
//        }
//    }
//
//    //move ball on every frame
//    ball.xc+=ball.vx;
//    ball.yc+=ball.vy;
//
//    //check collision of ball and platform
//    //if ball hits the edges of platform,it reflects with random angle
//    platform_collision();
//
//    //check collision of ball and walls
//    if(ball.xc>W-ball.R || ball.xc<ball.R) ball.vx*=-1;
//    if(ball.yc<ball.R) ball.vy*=-1;
//
//    //check lives
//    if(ball.yc>=H-ball.R && lives>0)
//    {
//       ball.yc=platform.yc-ball.R-5;
//       ball.xc=platform.xc;
//       SDL_PollEvent(e);
//       ball.vx=0.5;
//       ball.vy=0.5;
//       lives--;
//    }
//    else if(ball.yc>H-ball.R && lives==0)
//        break;
//
//    //check platform to be in screen
//    if(platform.xc>W+100) platform.xc=-100;
//    else if(platform.xc<-100) platform.xc=W+100;
//
//    //draw platform
//    boxRGBA(m_renderer,platform.xc-100,platform.yc-5,platform.xc+100,platform.yc+5,0,0,255,255);
//
//    //draw ball
//    filledEllipseRGBA(m_renderer,ball.xc,ball.yc,ball.R,ball.R,0,255,0,255);
//
//
//
//
//
//    SDL_SetRenderDrawColor( m_renderer,0,0,0,255 );
//    SDL_RenderPresent(m_renderer);
//    SDL_RenderClear( m_renderer );
//
//    }
//
//
//
//
//
//
//
//
//
//    //Finalize and free resources
//    //SDL_DestroyTexture(m_img);
//    SDL_DestroyWindow( m_window );
//    SDL_DestroyRenderer( m_renderer );
//	IMG_Quit();
//	SDL_Quit();
//    return 0;
//
//}
//


