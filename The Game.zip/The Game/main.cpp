/*/////////////////////////////////////////*
Ata Akbarizad : 99101184
Saeid Elahi Asl














//////////////////////////////////////////////////*/
#include <string>
#include <fstream>
#include <ctime>
#include <cmath>
#include <iostream>
#include <SDL_ttf.h>
#include <SDL.h>
#include <SDL_image.h>
#include <SDL2_gfx.h>
#include <SDL_mixer.h>
#include <random>
using namespace std;

int SCREEN_WIDTH = 1245;
int SCREEN_HEIGHT = 720;

//The window we'll be rendering to
SDL_Window* gWindow = NULL;
SDL_Renderer* renderer= NULL;
TTF_Font *gFont = NULL;
TTF_Font *g18Font = NULL;
Mix_Chunk *music = NULL;
Mix_Music *main_music = NULL;
Mix_Music *misic = NULL;

//The surface contained by the window

SDL_Surface* gTempSurface = NULL;
SDL_Texture* gTempTexture = NULL;
SDL_Texture* nameMenu = NULL;
SDL_Texture* brickPhoto100 = NULL;
SDL_Texture* brickPhoto75 = NULL;
SDL_Texture* brickPhoto50 = NULL;
SDL_Texture* brickPhoto25 = NULL;
SDL_Texture* brickPhoto0 = NULL;
SDL_Texture* levelTex = NULL;
SDL_Texture* scoreTex = NULL;
SDL_Texture* livTex = NULL;
SDL_Texture* hardnes = NULL;



//The image we will load and show on the screen
//SDL_Surface* gHelloWorld = NULL;

const int length=140,
width=50,
dist=15;
bool hesoyam_used=false;


//////////////////////////funcs/////////////////////////////

void statUpdate(int level,int score, int lives,SDL_Texture* &stat){

    string text = "Level: " + to_string(level) + "  Score: " + to_string(score) + "  Lives: " + to_string(lives);
    SDL_Color col23={255,255,255,255};
    gTempSurface = TTF_RenderText_Solid(g18Font,&text[0],col23);
    stat = SDL_CreateTextureFromSurface(renderer,gTempSurface);

}
void randomCol(int &r,int &g,int &b){// creates a hsl bright color then gives rgb

    short int deg = rand()%360 ;
    float x = 1-abs(  deg / 60.0  - deg/60 + (deg/60)%2-1);
    if(deg >= 300){
        r = 255;
        g = 0;
        b = x*255;
        }
    else if(deg >= 240){
        r = x*255;
        g = 0;
        b = 255;
        }
    else if(deg >= 180){
        r = 0;
        g = x*255;
        b = 255;
        }
    else if(deg >= 120){
        r = 0;
        g = 255;
        b = x*255;
        }
    else if(deg >= 60){
        r = x*255;
        g = 255;
        b = 0;
        }
    else {
        r = 255;
        g = x*255;
        b = 0;
        }

}
int randomCol(int &hue){


    int r,g,b;


    short int deg ;
    deg = hue;
    float x = 1-abs(  deg / 60.0  - deg/60 + (deg/60)%2 -1);
    if(deg >= 300){
        r = 255;
        g = 0;
        b = x*255;
        }
    else if(deg >= 240){
        r = x*255;
        g = 0;
        b = 255;
        }
    else if(deg >= 180){
        r = 0;
        g = x*255;
        b = 255;
        }
    else if(deg >= 120){
        r = 0;
        g = 255;
        b = x*255;
        }
    else if(deg >= 60){
        r = x*255;
        g = 255;
        b = 0;
        }
    else {
        r = 255;
        g = x*255;
        b = 0;
        }
        return 0xff*256*256*256 + b*256*256 + g*256 + r;
}

void randomCol(int hue,int &r,int &g, int &b){





    short int deg ;
    deg = hue;
    float x = 1-abs(  deg / 60.0  - deg/60 + (deg/60)%2 -1);
    if(deg >= 300){
        r = 255;
        g = 0;
        b = x*255;
        }
    else if(deg >= 240){
        r = x*255;
        g = 0;
        b = 255;
        }
    else if(deg >= 180){
        r = 0;
        g = x*255;
        b = 255;
        }
    else if(deg >= 120){
        r = 0;
        g = 255;
        b = x*255;
        }
    else if(deg >= 60){
        r = x*255;
        g = 255;
        b = 0;
        }
    else {
        r = 255;
        g = x*255;
        b = 0;
        }
        return;
}
//void shift(brickclass[10][8], int*);

//////////////////////////classes///////////////////////////

class brickclass{

public:
    int xc, yc;
    //bool exist=0;
    int strength,first_strength=0;
    SDL_Rect R={xc-168/2,yc-78/2,168,78};
    bool render(){

        R={xc-168/2,yc-78/2,168,78};

        //stringColor(renderer,xc-length/2,yc-width/2,&to_string(strength)[0],0xffffffff);
        if(strength){
            if(strength==first_strength){//boxColor(renderer,xc-length/2 ,yc-width/2, xc+length/2, yc+width/2,0xffff0000);
                int r,g,b;
                randomCol(strength*5,r,g,b);
                SDL_SetTextureColorMod(brickPhoto100,r,g,b);
                SDL_RenderCopy(renderer,brickPhoto100,NULL,&R);

            }else if(strength>= 3 / 4.0 *first_strength){ //boxColor(renderer,xc-length/2 ,yc-width/2, xc+length/2, yc+width/2,0xffff0000);
                int r,g,b;
                randomCol(strength*5,r,g,b);
                SDL_SetTextureColorMod(brickPhoto75,r,g,b);


                SDL_RenderCopy(renderer,brickPhoto75,NULL,&R);

            }else if(strength>=  0.5 *first_strength){ //boxColor(renderer,xc-length/2 ,yc-width/2, xc+length/2, yc+width/2,0xffff0000);
                int r,g,b;
                randomCol(strength*5,r,g,b);
                SDL_SetTextureColorMod(brickPhoto50,r,g,b);
                SDL_RenderCopy(renderer,brickPhoto50,NULL,&R);

            }else if(strength>=  1 / 4.0 *first_strength){ //boxColor(renderer,xc-length/2 ,yc-width/2, xc+length/2, yc+width/2,0xffff0000);
                int r,g,b;
                randomCol(strength*5,r,g,b);
                SDL_SetTextureColorMod(brickPhoto25,r,g,b);
                SDL_RenderCopy(renderer,brickPhoto25,NULL,&R);
            }else { //boxColor(renderer,xc-length/2 ,yc-width/2, xc+length/2, yc+width/2,0xffff0000);
                int r,g,b;
                randomCol(strength*5,r,g,b);
                SDL_SetTextureColorMod(brickPhoto0,r,g,b);
                SDL_RenderCopy(renderer,brickPhoto0,NULL,&R);
            }
        }
        else return false;
        return true;
    }
//    ~brickclass(){
//        SDL_DestroyTexture()
//
//    }


};

class platformclass{

public:
    int xc;
    int yc;
    int vx=4;
    int length=235;
    int width=42;
    SDL_Rect temp;


    SDL_Texture *aks =NULL;

    platformclass(){

    aks = IMG_LoadTexture(renderer,"platdesign.png");
    SDL_SetTextureBlendMode(aks,SDL_BLENDMODE_BLEND);


    SDL_SetTextureColorMod(aks,0,184,255);
    }

    bool update(SDL_Event *e){


        SDL_PollEvent(e);
        if(e!= NULL && e->type==SDL_KEYDOWN)
        {
            switch(e->key.keysym.sym)
            {
                case SDLK_ESCAPE:
                  return false;
                  break;
                case SDLK_RIGHT:
                  xc+=vx;
                  return true;
                  break;
                case SDLK_LEFT:
                  xc-=vx;
                  return true;
                  break;
            }
        }
        //check platform to be in screen
        if(xc>SCREEN_WIDTH+length/2) xc=-length/2;
        else if(xc<-length/2) xc=SCREEN_WIDTH+length/2;
        return true;
    }
    bool multiplater_update(const Uint8* keys,int player){

        //check platform to be in screen
        if(xc>SCREEN_WIDTH+length/2) xc=-length/2;
        else if(xc<-length/2) xc=SCREEN_WIDTH+length/2;

        if(keys[SDL_GetScancodeFromKey(SDLK_ESCAPE)])
            return false;
        if(keys[SDL_GetScancodeFromKey(SDLK_RIGHT)] && player==1){
            xc+=vx;
            return true;
        }

        if(keys[SDL_GetScancodeFromKey(SDLK_LEFT)] && player==1){
            xc-=vx;
            return true;
        }

        if(keys[SDL_GetScancodeFromKey(SDLK_KP_6)] && player==2){
            xc+=vx;
            return true;
        }

        if(keys[SDL_GetScancodeFromKey(SDLK_KP_4)] && player==2){
            xc-=vx;
            return true;
        }
        return false;

    }

    void render(){
        temp = {xc-length/2-70,yc-width/2-16,372,112};
        //boxRGBA(renderer,xc-length/2 ,yc-width/2, xc+length/2, yc+width/2,255,255,0,255);


        SDL_RenderCopy(renderer,aks,NULL,&temp);
    }
};

class ball{
public:
    int damage;
    float xc=600,yc=800;
    int angle;
    float vx,vy;
    float v=2;
    int R=10;
    int hue = 0;
    int checkDastance = (length/2+R)*(length/2+R) + (width/2+R)*(width/2+R) + 5;


    void setAng(int start, int end){  // chooses angle between strat and end

        angle = (rand()%(end - start)) + start;
        cout<< angle;
        vx = v*cos( angle / 180.0 * 3.1415);
        vy = -v*sin( angle / 180.0 * 3.1415);
    }

    void setAng(int angle){
        vx = v*cos( angle / 180.0* 3.1415);
        vy = -v*sin( angle / 180.0 * 3.1415);
    }




    bool chckCollid(platformclass platform){

        if(xc>platform.xc-platform.length/2 && xc<platform.xc+platform.length/2 && yc>platform.yc-R-platform.width/2 && yc<platform.yc-R)
            {vy*=-1;  return true; }


        else if(  (xc - (platform.xc - platform.length/2)) * (xc - (platform.xc - platform.length/2))+
            (yc - (platform.yc - platform.width/2)) * (yc - (platform.yc - platform.width/2)) <=  (R * R)  )
                {setAng(90,180);  return true;}


        else if (  (xc - (platform.xc + platform.length/2)) * (xc - (platform.xc + platform.length/2))+
            (yc - (platform.yc - platform.width/2)) * (yc - (platform.yc - platform.width/2)) <= (R * R)  )
                {setAng(0,90);  return true;}
        return false;

    }



    bool chckCollid(brickclass brick){


        if(brick.strength && (xc-brick.xc)*(xc-brick.xc)+(yc-brick.yc)*(yc-brick.yc) < checkDastance){

            //aalineColor(renderer,xc,yc,brick.xc,brick.yc,0xffffffff);
            if(yc<R+brick.yc+width/2 && xc<brick.xc+length/2 &&
                xc>brick.xc-length/2 && yc>brick.yc-width/2-R)

            {
                vy*=-1;

                return true;
            }

            else if(xc> brick.xc-length/2-R && yc < brick.yc+width/2 &&
                    yc>brick.yc-width/2 && xc< R+brick.xc+length/2 )
            {
                vx*=-1;
                return true;


            } else

                if(  (xc - (brick.xc - length/2)) * (xc - (brick.xc - length/2))+
                (yc - (brick.yc - width/2)) * (yc - (brick.yc - width/2)) <=  (R * R))

                    {setAng(90,180);  return true;}


                else if (  (xc - (brick.xc + length/2)) * (xc - (brick.xc + length/2))+
                (yc - (brick.yc - width/2)) * (yc - (brick.yc - width/2)) <= (R * R))
                    {setAng(0,90);  return true;}


                else if (  (xc - (brick.xc + length/2)) * (xc - (brick.xc + length/2))+
                (yc - (brick.yc + width/2)) * (yc - (brick.yc + width/2)) <=  (R * R))
                    {setAng(270,360);  return true;}


                else if (  (xc - (brick.xc - length/2)) * (xc - (brick.xc - length/2))+
                (yc - (brick.yc + width/2)) * (yc - (brick.yc + width/2)) <= (R * R))
                    {setAng(180,270);  return true;}
        }
        return false;




    }
    bool update(brickclass brick[10][8],platformclass platform,int &level,int &score,int &live, SDL_Texture* &stat,bool &cheat_used){

        xc += vx;
        yc += vy;
        //check brick
        for(int i=0 ;i<10 ;i++){
            for(int j=0 ;j<8 ;j++){

                if( chckCollid(brick[i][j] ))
                {
                    int temp = brick[i][j].strength;
                    brick[i][j].strength -= damage;
                    if(brick[i][j].strength<=0){brick[i][j].strength=0; score += level;}
                    //cout << damage;
                    damage -= temp;
                    cout << damage<<endl;

                    Mix_PlayChannel(-1,(Mix_Chunk*)music,0);
                    xc += 2*vx;
                    yc += 2*vy;
                    //cout << i << " " << j<< endl;
                    string text = "Level: " + to_string(level) + "  Score: " + to_string(score) + "  Lives: " + to_string(live);

                    SDL_Color col23={255,255,255,255};
                    gTempSurface = TTF_RenderText_Solid(g18Font,&text[0],col23);

                    stat = SDL_CreateTextureFromSurface(renderer,gTempSurface);

                    if(damage<=0){
                            damage =0;
                            return 1;
                    }
                }

            }
        }
//        int i = ((int)(xc-10)%(length+dist))%8;
//        int j = ((int)(yc-10)%(width+dist))%10;
//
//        if( chckCollid(brick[i][j] ))
//                {
//                    brick[i][j].strength--;
//                    Mix_PlayMusic(music, 1);
//                    xc += 2*vx;
//                    yc += 2*vy;
//                    //cout << i << " " << j<< endl;
//                }
//        else if( i<9 && chckCollid(brick[i+1][j] ))
//                {
//                    brick[i+1][j].strength--;
//                    Mix_PlayMusic(music, 1);
//                    xc += 2*vx;
//                    yc += 2*vy;
//                    //cout << i << " " << j<< endl;
//                }
//        else if( j<7 && chckCollid(brick[i][j+1] ))
//                {
//                    brick[i][j+1].strength--;
//                    Mix_PlayMusic(music, 1);
//                    xc += 2*vx;
//                    yc += 2*vy;
//                    //cout << i << " " << j<< endl;
//                }
//        else if(j<7 && i<9 && chckCollid(brick[i+1][j+1] ))
//                {
//                    brick[i+1][j+1].strength--;
//                    Mix_PlayMusic(music, 1);
//                    xc += 2*vx;
//                    yc += 2*vy;
//                    //cout << i << " " << j<< endl;
//                }
//        else if(j>0 && i>0 && chckCollid(brick[i-1][j-1] ))
//                {
//                    brick[i-1][j-1].strength--;
//                    Mix_PlayMusic(music, 1);
//                    xc += 2*vx;
//                    yc += 2*vy;
//                    //cout << i << " " << j<< endl;
//                }
//
//       else if( j>0 && chckCollid(brick[i][j-1] ))
//                {
//                    brick[i][j-1].strength--;
//                    Mix_PlayMusic(music, 1);
//                    xc += 2*vx;
//                    yc += 2*vy;
//                    //cout << i << " " << j<< endl;
//                }
//        else if( i>0 && chckCollid(brick[i-1][j] ))
//                {
//                    brick[i-1][j].strength--;
//                    Mix_PlayMusic(music, 1);
//                    xc += 2*vx;
//                    yc += 2*vy;
//                    //cout << i << " " << j<< endl;
//                }
//
//
//        else if( j<7 && i>0 && chckCollid(brick[i-1][j+1] ))
//                {
//                    brick[i-1][j+1].strength--;
//                    Mix_PlayMusic(music, 1);
//                    xc += 2*vx;
//                    yc += 2*vy;
//                    //cout << i << " " << j<< endl;
//                }
//        else if( j>0 && i<9 && chckCollid(brick[i+1][j-1] ))
//                {
//                    brick[i+1][j-1].strength--;
//                    Mix_PlayMusic(music, 1);
//                    xc += 2*vx;
//                    yc += 2*vy;
//                    //cout << i << " " << j<< endl;
//                }


        if( chckCollid(platform))
        {
            //Mix_PlayMusic(music, 1);
            xc += 2*vx;
            yc += 2*vy;
        }

        //check collision of ball and walls
        if(xc>SCREEN_WIDTH-R || xc<R) {vx*=-1; xc+=2*vx; }
        if(yc<R) {vy*=-1; yc+=2*vy;}
        if(yc > SCREEN_HEIGHT) {live--; cheat_used=false; hesoyam_used=false; return 1;}
        return 0;

    }
    void render(){

        hue++;
        if(hue>=360) hue=0;
        //cout << hue<< endl;
        filledCircleColor(renderer,xc,yc,R,randomCol(hue));

        //SDL_RenderPresent(renderer);

    }





};
class lableBox{
public:
    float hue=0;
    bool isnew;
    SDL_Texture* aks = NULL;
    SDL_Texture* matn = NULL;
    unsigned short int x,y,w=680,h=300;
    //string text;
    int recordCount;
    int *lives, *levels, *scores;

    string live="Lives    ",sco="Score   ",leve="Level    ";
    lableBox(int x_,int y_, string name,string saves,bool isNew){
        isnew = isNew;
        //aks = IMG_LoadTexture(renderer, "lableBox.bmp");  //akse box
        x= x_ - w/2;
        y= y_ - h/2;
        hue = rand()%360;
        if(isNew){



        }else{

        //////////////////////////getting record from file string/////////////////////////

        //name = "@"+name+"<";
        int record_count_Position = saves.find(name)+name.length()+2;  // +4  is for <c> in the save file
        recordCount =(int) saves[record_count_Position]-'0';


        lives = new int[recordCount];
        levels = new int[recordCount];
        scores = new int[recordCount];


        int lastChecked_index = record_count_Position;
        for(int i=0; i<recordCount ; i++){                                     //inaro lazem nist bexuni


            string temp;

            //cout<<saves.find("<lev>",lastChecked_index)+5 << endl << saves.find("</lev>",lastChecked_index)<< endl;
            temp = saves.substr(saves.find("<lev>",lastChecked_index)+5,
                                saves.find("</lev>",lastChecked_index)-saves.find("<lev>",lastChecked_index)-5);
            //cout<< temp;
            levels[i] = stoi(temp);

            temp = saves.substr(saves.find("<s>",lastChecked_index)+3,
                                saves.find("</s>",lastChecked_index)-saves.find("<s>",lastChecked_index)-3);
            scores[i] =stoi(temp);

            temp = saves.substr(saves.find("<liv>",lastChecked_index)+5,
                                saves.find("</liv>",lastChecked_index)-saves.find("<liv>",lastChecked_index)-5);
            //cout << (temp);
            lives[i] =stoi(temp);


            lastChecked_index = saves.find("</liv>",lastChecked_index)+5;


        }}
        /////////////////////////loading aks to main texture////////////////////
        //aks = SDL_CreateTexture(renderer,SDL_PIXELFORMAT_RGB888,SDL_TEXTUREACCESS_TARGET,w,h);
        aks = IMG_LoadTexture(renderer,"lableBox.png");
        SDL_SetTextureBlendMode(aks,SDL_BLENDMODE_ADD);
        //SDL_SetRenderTarget(renderer,aks);
        //SDL_RenderCopy(renderer,temp,NULL,NULL);
        //SDL_RenderPresent(renderer);
        //cout<<SDL_GetError()<<"beep";

        //SDL_RenderCopy(renderer,temp,NULL,NULL);
        //SDL_SetRenderTarget(renderer,NULL);
        //SDL_RenderCopy(renderer,aks,NULL,NULL);
        //SDL_RenderPresent(renderer);
        //free(temp);



        ///////////////////////////creating text////////////////////////

        ///////creating string////////

        if (isNew){
            leve = "No record!";
            sco ="";
            live="";
        }else{


            for(int i = 0; i<recordCount;i++){
                live += to_string(lives[i]) + "    ";
                sco +=  to_string(scores[i]) + "    ";
                leve +=  to_string(levels[i]) + "    ";

            }

        }


    }

    void render(){

        int r,g,b;
        randomCol(hue ,r, g, b);
        SDL_SetTextureColorMod(aks,r,g,b);
        hue+=.5;
        if(hue>=360)hue = 0;

        SDL_Rect temp={x-18,y-18,w,h};
        SDL_RenderCopy(renderer,aks,NULL,&temp);
        ////////creating texture//////////
        SDL_Color col ={255,255,255,255};

        gTempSurface = TTF_RenderText_Solid( gFont, &leve[0], col);  // dorost kardan matn ba font ba ttf
        matn = SDL_CreateTextureFromSurface( renderer, gTempSurface );


        ///////////////////render copy for level/////////////////////
        int tempW,tempH;
        SDL_QueryTexture(matn,NULL,NULL,&tempW,&tempH);
        SDL_Rect temp2={ x+30 , y+84, isnew?120:(450/(6-recordCount)+200), tempH };   //tanzim mokhtasat matn baraye copy
        SDL_RenderCopy(renderer,matn,NULL,&temp2);

        ///////////////////render copy for score/////////////////////


        gTempSurface = TTF_RenderText_Solid( gFont,&sco[0], col );  // dorost kardan matn ba font ba ttf
        matn = SDL_CreateTextureFromSurface( renderer, gTempSurface );

        SDL_QueryTexture(matn,NULL,NULL,&tempW,&tempH);
        temp2={ x+30 , y+124, 450/(6-recordCount)+200, tempH };   //tanzim mokhtasat matn baraye copy
        SDL_RenderCopy(renderer,matn,NULL,&temp2);


        ///////////////////render copy for life/////////////////////

        gTempSurface = TTF_RenderText_Solid( gFont,&live[0], col );  // dorost kardan matn ba font ba ttf
        matn = SDL_CreateTextureFromSurface( renderer, gTempSurface );

        SDL_QueryTexture(matn,NULL,NULL,&tempW,&tempH);
        temp2={ x+30 , y+164, 450/(6-recordCount)+200, tempH };   //tanzim mokhtasat matn baraye copy
        SDL_RenderCopy(renderer,matn,NULL,&temp2);



        free(gTempSurface);



    }




};

class textBox{
public:

    SDL_Texture* aks = NULL;
    SDL_Texture* matn = NULL;
    unsigned short int x,y,w=400,h=104 ,aks_w=400,aks_h=104;


    char text[20];         //matn dakhele box
    int currentTextIndex=0;       //index baraye neveshtan char


    textBox(){
        aks = IMG_LoadTexture(renderer, "textBox.png");  //akse box
        SDL_SetTextureBlendMode(aks,SDL_BLENDMODE_ADD);
        SDL_SetTextureBlendMode(matn,SDL_BLENDMODE_ADD);
        x= SCREEN_WIDTH/2 - aks_w/2;
        y= SCREEN_HEIGHT/2 - aks_h/2;
        for(int i =0;i<20;i++)
            text[i]='\0';

//IMG_LoadTexture()

    }
    void render(){
        SDL_Color col ={255,255,255,255};
        gTempSurface = TTF_RenderText_Solid( gFont,text, col );
        matn = SDL_CreateTextureFromSurface( renderer, gTempSurface );   // dorost kardan matn ba font ba ttf
        free(gTempSurface);
        SDL_Rect tempRect={x,y,aks_w,aks_h};  // tanzim mokhtasat aks
        //boxColor(renderer,0,0,100,100,0xffffffff);
        SDL_RenderCopy(renderer,aks,NULL,&tempRect);         // copy kardan aks background ruuye target renderr
        int tempW,tempH;
        SDL_QueryTexture(matn,NULL,NULL,&tempW,&tempH);
        SDL_Rect temp2={x+ w/2 - (tempW)/2 , y+h/2-10, tempW, tempH };   //tanzim mokhtasat matn
        SDL_RenderCopy(renderer,matn,NULL,&temp2);


    }
    void addText(SDL_Event e){

        if( (e.key.keysym.sym == SDLK_BACKSPACE)){

            if(currentTextIndex!=0){
                currentTextIndex--;
                text[currentTextIndex] = '\0';
                render();
                SDL_RenderPresent(renderer);
            }


        }else if((currentTextIndex < 19)&& ((e.key.keysym.sym >='a' && e.key.keysym.sym <='z') ||
                                                                                (e.key.keysym.sym >='A' && e.key.keysym.sym <='Z')||
                                                                                (e.key.keysym.sym >='0' && e.key.keysym.sym <='9') ||
                                                                                e.key.keysym.sym ==' ') ){
            text[currentTextIndex] =(char) e.key.keysym.sym;
            render();
            SDL_RenderPresent(renderer);
            currentTextIndex ++;


        }
    }



};
class Button{
public:

    SDL_Texture* aks = NULL;
    SDL_Texture* aks_inverted = NULL;
    SDL_Texture* matn = NULL;
    SDL_Texture* temp= NULL;
    unsigned short int x,y,w=318,h=124;
    int tempW,tempH;
    SDL_Rect temp2;
    bool clicked=0;
    float hue;


    char *text;         //matn dakhele box
    int currentTextIndex=0;       //index baraye neveshtan char


    Button(char* button_text,int x_,int y_){
        hue = rand()%360;

        //////////////dorost kardan texture matn////////////
        SDL_Color col ={255,255,255,255};
        gTempSurface = TTF_RenderText_Solid( gFont,button_text, col );  // dorost kardan matn ba font ba ttf
        //if(gTempSurface== nullptr)cout<<",mmm";
        matn = SDL_CreateTextureFromSurface( renderer, gTempSurface );
        SDL_SetTextureBlendMode(matn,SDL_BLENDMODE_ADD);
        free(gTempSurface);


        SDL_QueryTexture(matn,NULL,NULL,&tempW,&tempH);
        //temp2={ w/2 - (tempW)/2 , h/2-16, tempW, tempH };   //tanzim mokhtasat matn baraye copy

        /////////////////////load kardane aks ha//////////////////////

        //aks =   SDL_CreateTexture(renderer,SDL_PIXELFORMAT_RGBA8888,SDL_TEXTUREACCESS_TARGET,w,h);
        //SDL_SetRenderTarget(renderer,aks);
        //SDL_SetRenderDrawColor(renderer,0,0,0,0);
        //SDL_RenderClear(renderer);
        //temp = IMG_LoadTexture(renderer, "butt.png");  //akse button
        //SDL_SetTextureBlendMode(temp,SDL_BLENDMODE_BLEND);
        //SDL_SetTextureBlendMode(aks,SDL_BLENDMODE_BLEND);
        //SDL_RenderCopy(renderer,temp,NULL,NULL);
        //SDL_RenderCopy(renderer,matn,NULL,&temp2);   //copy matn rooye aks


        //temp2 = {318/2 - (tempW)/2 , 124/2-16, tempW, tempH};
//        aks_inverted = SDL_CreateTexture(renderer,SDL_PIXELFORMAT_RGBA8888,SDL_TEXTUREACCESS_TARGET,318,124);
//        SDL_SetRenderTarget(renderer,aks_inverted);

        temp = IMG_LoadTexture(renderer, "butt_inv.png");  //akse button
        SDL_SetTextureBlendMode(temp,SDL_BLENDMODE_ADD);
       // SDL_SetTextureBlendMode(aks_inverted,SDL_BLENDMODE_ADD);
       // SDL_SetRenderTarget(renderer,aks_inverted);
        //SDL_RenderCopy(renderer,temp,NULL,NULL);
        //SDL_SetTextureColorMod(matn,0,0,0);
        //SDL_RenderCopy(renderer,matn,NULL,&temp2);   //copy matn rooye aks

        //SDL_SetRenderTarget(renderer,NULL);


        //SDL_DestroyTexture(temp);
        //x= x_ - w/2;
        //y= y_ - h/2;
        x= x_ ;
        y= y_ ;
        text = button_text;


        ///////////////ezafe kardane matne button//////////////


    }
    void render(bool darken){
        if(0){

            SDL_Rect tempRect={x-w/2,y-h/2,w,h};  // tanzim mokhtasat aks
            int r,g,b;
            randomCol(r,g,b);

            if(!darken)SDL_SetTextureColorMod(aks_inverted,r,g,b);
            else SDL_SetTextureColorMod(aks_inverted,r/2,g/2,b/2);
            SDL_RenderCopy(renderer,aks,NULL,&tempRect);

        }else{

            temp2 = {x - (tempW)/2 , y-16, tempW, tempH};

            SDL_Rect tempRect={x-318/2,y-124/2,318,124};  // tanzim mokhtasat aks
            int r,g,b;
            randomCol(hue,r,g,b);
            SDL_SetTextureColorMod(temp,r,g,b);
            SDL_RenderCopy(renderer,temp,NULL,&tempRect);
            SDL_SetTextureColorMod(matn,r,g,b);
            SDL_RenderCopy(renderer,matn,NULL,&temp2);

            hue+=.5;
            if(hue >= 360)hue=0;
//            randomCol(hue,r,g,b);
//            SDL_SetTextureColorMod(temp,r,g,b);
//            SDL_RenderCopy(renderer,temp,NULL,&tempRect);
//            SDL_SetTextureColorMod(matn,r,g,b);
//            SDL_RenderCopy(renderer,matn,NULL,&temp2);   //copy matn rooye aks

        }


    }
    ~Button(){

        SDL_DestroyTexture(aks);
        SDL_DestroyTexture(aks_inverted );
        SDL_DestroyTexture(matn );

        SDL_DestroyTexture(temp);


    }




};


void shift(brickclass brick[10][8], int &level,int hardness){
    level++;
    float a;

    switch (hardness){
    case 0:
        a = 7.0;
    break;
    case 1:
        a = 5.0;
    break;
    case 2:
        a = 3.0;
    break;


    }
    static default_random_engine generator(time(0));
    normal_distribution<float> distribution(level/a,2);
    //distribution(generator);
    for(int i = 10; i>0 ; i--){

        for(int j = 0; j<8 ; j++){

            if(i!=1){

                    brick[i-1][j].strength = brick[i-2][j].strength;
                    brick[i-1][j].first_strength = brick[i-2][j].first_strength;
            }

            else {

                    brick[i-1][j].first_strength = int(abs(distribution(generator))) % level;
                    brick[i-1][j].strength = brick[i-1][j].first_strength;
            }


        }

    }

}


//Starts up SDL and creates window
bool init();

//Loads media
bool loadMedia();

//Frees media and shuts down SDL
void close();


/**
*    the     main
*
*
*/
int main( int argc, char* args[] )
{



////////////////save file init//////////////
    fstream out;
    out.open("saves.txt", ios_base::in);
    out.seekg(0, std::ios::end);
    size_t size = out.tellg();
                                        //+++++ MOHEM ++++
    string saves(size, ' ');              //darmorede ina natars   hamasho copy paste kardam khodamam nemidunm chie
    //out.ignore();                       //fgt bedun ke file ro miare tu ye string
    out.seekg(0);
    out.read(&saves[0],size);
    //cout<<saves;
    out.close();
//////////////////////////////////////////
	short int hardness=0;
	bool quit = false;
	SDL_Event e;
	init();
	IMG_Init(IMG_INIT_PNG);
	Mix_Init(MIX_INIT_MOD);
	Mix_OpenAudio(MIX_DEFAULT_FREQUENCY,MIX_DEFAULT_FORMAT, 8, 1024);
    srand(time(0));
    music = Mix_LoadWAV("hit.wav");
    main_music = Mix_LoadMUS("champions_league_anthem.ogg");
    misic=Mix_LoadMUS("misic.mp3");
///////////////font init///////////////
	TTF_Init();
	gFont = TTF_OpenFont( "pixel.ttf", 28 );
		g18Font = TTF_OpenFont( "pixel.ttf", 18 );

/////////////////////////////////////////
////////////////backgroudn load///////////
    SDL_Texture* background;
    background = IMG_LoadTexture(renderer, "xx1.jpg");
    SDL_RenderCopy(renderer,background,NULL,NULL);
/////////////////////first name text box//////////////

    textBox* name = new textBox();
    name->render();
    SDL_RenderPresent(renderer);
///////////////////////////////////////////////////
    brickPhoto100 = IMG_LoadTexture(renderer, "100.png");
    SDL_SetTextureColorMod(brickPhoto100,0,184,255);
    brickPhoto75 = IMG_LoadTexture(renderer, "75.png");
    SDL_SetTextureColorMod(brickPhoto75,255,108,0);
    brickPhoto50 = IMG_LoadTexture(renderer, "50.png");
    SDL_SetTextureColorMod(brickPhoto50,255,108,0);
    brickPhoto25 = IMG_LoadTexture(renderer, "25.png");
    SDL_SetTextureColorMod(brickPhoto25,255,108,0);
    brickPhoto0 = IMG_LoadTexture(renderer, "0.png");
    SDL_SetTextureColorMod(brickPhoto0,213,19,0);
        //Update the surface
    SDL_Color colsf={255,255,255,255};
    hardnes = SDL_CreateTextureFromSurface(renderer,TTF_RenderText_Solid(gFont,"Hardness",colsf));
    SDL_SetTextureBlendMode(hardnes,SDL_BLENDMODE_ADD);

    Mix_PlayMusic(main_music,1);
    while( !quit )
    {
        //Handle events on queue
        //Mix_PlayMusic(main_music,1);
        bool exi =0;
        while( SDL_PollEvent( &e ) != 0 && !exi)
        {
            //User requests quit

            if( e.type == SDL_QUIT )
            {
                quit = true;
            }else if(e.type == SDL_KEYDOWN && e.key.keysym.sym == SDLK_RETURN)
            {


                string Name = name->text;
                Name = "@" +Name+ "<";
                //cout << Name << "ll";


                unsigned int namePos= saves.find(Name);    //position of the name in the text
                bool isNew = (namePos == string::npos);


//                if(namePos == string::npos){  //agar esm dar file mojod nabashad
//
//                    isNew = 1;
//                }
//                else{
//                    isNew = 0;
//
//                }

                SDL_RenderCopy(renderer,background,NULL,NULL);

                //////////////////////buttons////////////////////////////

                Button* newG = new Button("New Game",850,500);  //new game butto
                newG->render(0);
                //newG->render(0);

                Button* load = new Button("Load",350,500);  //continue button
                if(!isNew){load->render(!isNew);
                    //load->render(!isNew);
                }

                Button* multiFriend = new Button("multiFriend",850,600);  //new game butto
                multiFriend->render(0);
                //multiFriend->render(0);

                Button* multiEnemy = new Button("multiEnemy",350,600);  //continue button
                multiEnemy->render(0);
                //multiEnemy->render(0);


                //SDL_RenderPresent(renderer);


                /////////////////lable box/////////////////////////////////

                lableBox* my= new lableBox(610,300,Name,saves,isNew);
                my->render();
                SDL_RenderPresent(renderer);


                ////////////////button control////////////////////////////


                bool newGflag=0,loadflag=0,enem=0,frien=0;
                while(!(newGflag || loadflag || enem || frien)){


                    SDL_SetTextureColorMod(hardnes,0,255,0);
                    SDL_Rect rec={SCREEN_WIDTH/2-25,SCREEN_HEIGHT-15,50,15};
                    SDL_RenderCopy(renderer,hardnes,NULL,&rec);
                    while(e.type != SDL_MOUSEBUTTONDOWN){
                        SDL_PollEvent(&e);

                        if(e.type == SDL_KEYUP ){
                                //cout<< hardness;
                            switch (e.key.keysym.sym){
                                case SDLK_KP_0:
                                SDL_SetTextureColorMod(hardnes,0,255,0);
                                hardness =0;
                                break;
                                case SDLK_KP_1:
                                SDL_SetTextureColorMod(hardnes,255,255,0);
                                hardness =1;
                                break;
                                case SDLK_KP_2:
                                    SDL_SetTextureColorMod(hardnes,255,0,0);
                                    hardness =2;
                                break;

                            }
//                            SDL_Rect rec={SCREEN_WIDTH/2,SCREEN_HEIGHT-10,50,10};
//                            SDL_RenderCopy(renderer,hardnes,NULL,&rec);

                        }

                        SDL_RenderCopy(renderer,background,0,0);
                        SDL_Rect rec={SCREEN_WIDTH/2-50,SCREEN_HEIGHT-15,50,15};
                        SDL_RenderCopy(renderer,hardnes,NULL,&rec);
                        newG->render(0);
                        if(!isNew)load->render(0);
                        multiEnemy->render(0);
                        multiFriend->render(0);
                        my->render();
                        SDL_RenderPresent(renderer);


                        }

                    //cout << newG->x - newG->w/2 << " < " << e.button.x << " < " << newG->x + newG->w/2 << endl;
                    //cout << newG->y - newG->h/2 << " < " << e.button.y << " < " << newG->y + newG->h/2 << endl;
                    //if(e.type == SDL_MOUSEBUTTONDOWN){


                    //} else if(0);// for handling escape button currently empty
                    while(e.type != SDL_MOUSEBUTTONUP)
                        SDL_PollEvent(&e);

                    if(e.button.x < newG->x + newG->w/2  &&  e.button.x > newG->x - newG->w/2  &&
                        e.button.y < newG->y + newG->h/2  &&  e.button.y > newG->y - newG->h/2)
                        newGflag =1;

                    else if(e.button.x < load->x + load->w/2  &&  e.button.x > load->x - load->w/2  &&
                            e.button.y < load->y + load->h/2  &&  e.button.y > load->y - load->h/2 && !isNew)
                        loadflag = 1;

                    else if(e.button.x < multiEnemy->x + multiEnemy->w/2  &&  e.button.x > multiEnemy->x - multiEnemy->w/2  &&
                        e.button.y < multiEnemy->y + multiEnemy->h/2  &&  e.button.y > multiEnemy->y - multiEnemy->h/2)
                        {enem =1;}

                    else if(e.button.x < multiFriend->x + multiFriend->w/2  &&  e.button.x > multiFriend->x - multiFriend->w/2  &&
                            e.button.y < multiFriend->y + multiFriend->h/2  &&  e.button.y > multiFriend->y - multiFriend->h/2)
                        {frien = 1;}

                }

                fstream bricks;
                    bricks.open("brick.txt",ios_base::in);
                    bricks.seekg(0, std::ios::end);
                    size_t size = bricks.tellg();
                    string brickData(size, ' ');              //this part reads brick.txt file
                    //out.ignore();                           //and puts the whole file into one string
                    bricks.seekg(0);
                    bricks.read(&brickData[0],size);
                    bricks.close();


                bool multiplayer=false;
                int player;
                const Uint8* keys = SDL_GetKeyboardState(NULL);
                int last_row;
                bool cheat_used=false;


                int level,lives,score,damage;
                int lives_,score_,damage_;



                brickclass brick[10][8];
                //brickclass bb[1][1];
                //Mix_FadeOutMusic()
                Mix_PlayMusic(misic,-1);
                if(newGflag){
                    level=1;
                    lives=3;
                    score=0;
                    damage=0;

                    for(int i = 0;i<10;i++)
                        for(int j=0;j<8;j++){
                            brick[i][j].first_strength=0;
                            brick[i][j].strength=0;
                        }



                }
                else if(frien){
                    level=1;
                    lives=3;
                    lives_=3;
                    score=0;
                    damage=0;
                    score_=0;
                    damage_=0;

                    multiplayer = 1;
                    for(int i = 0;i<10;i++)
                        for(int j=0;j<8;j++){
                            brick[i][j].first_strength=0;
                            brick[i][j].strength=0;
                        }



                }
                else if(enem){
                    level=1;
                    lives=3;
                    lives_=3;
                    score=0;
                    damage=0;
                    score_=0;
                    damage_=0;

                    multiplayer = 1;
                    for(int i = 0;i<10;i++)
                        for(int j=0;j<8;j++){
                            brick[i][j].first_strength=0;
                            brick[i][j].strength=0;
                        }



                }
                else if(loadflag){





                    level = my->levels[0];
                    lives = my->lives[0];
                    score = my->scores[0];


                    int currentIndex=brickData.find('>',brickData.find(Name));

                    damage = stoi(brickData.substr(currentIndex+1,brickData.find('/',currentIndex)-currentIndex-1));
                    //cout << damage;
                    currentIndex=brickData.find('/',brickData.find(Name));
                    //cout<< brickData;
                    for(int i = 0;i<10;i++)
                        for(int j=0;j<8;j++){
                            //cout << brickData.substr(currentIndex+1 ,brickData.find('/', currentIndex+1) - currentIndex-1);
                            brick[i][j].strength= stoi(brickData.substr(currentIndex+1 ,
                                                                         brickData.find('-', currentIndex+1) - currentIndex-1));

                            currentIndex = brickData.find('-', currentIndex+1);
                            brick[i][j].first_strength= stoi(brickData.substr(currentIndex+1 ,
                                                                         brickData.find('/', currentIndex+1) - currentIndex-1));

                            currentIndex = brickData.find('/', currentIndex+1);

                        }


                }


                SDL_Texture *stat= NULL;
                SDL_Texture *stat_=NULL;
                SDL_SetTextureColorMod(stat,0,184,255);
                SDL_SetTextureColorMod(stat_,0,255,184);

                string text = "Level: " + to_string(level) + "  Score: " + to_string(score) + "  Lives: " + to_string(lives);
                SDL_Color col23={255,255,255,255};
                gTempSurface = TTF_RenderText_Solid(g18Font,&text[0],col23);
                stat = SDL_CreateTextureFromSurface(renderer,gTempSurface);


                text = "Level: " + to_string(level) + "  Score: " + to_string(score_) + "  Lives: " + to_string(lives_);
                gTempSurface = TTF_RenderText_Solid(g18Font,&text[0],col23);
                stat_ = SDL_CreateTextureFromSurface(renderer,gTempSurface);


                //cout<< stat;
//                SDL_Color col ={255,255,255,255};
//                gTempSurface = TTF_RenderText_Solid( gFont,button_text, col );  // dorost kardan matn ba font ba ttf
//        if(gTempSurface== nullptr)cout<<",mmm";
//                matn = SDL_CreateTextureFromSurface( renderer, gTempSurface );

                //Mix_FadeOutMusic(1000);
                background = IMG_LoadTexture(renderer, "back4.jpg");
                SDL_RenderCopy(renderer,background,NULL,NULL);
                //SDL_RenderClear(renderer);
                for(int i=0;i<10;i++)
                for(int j=0;j<8;j++){

//                    if(brick[i][j].strength !=0){
//                        boxColor(renderer,j*(length+dist) ,i*(width+dist),j*(length+dist)+length,i*(width+dist)+width,0xffff0000);
//                        brick[i][j].exist =1;
//                    }
                    //if(brick[i][j].strength  > 0) brick[i][j].exist =1;
                    brick[i][j].xc = j*(length+dist)+ length/2+10;
                    brick[i][j].yc = i*(width+dist)+ width/2+10;
                    brick[i][j].render();
                    //stringRGBA(renderer,j*(length+dist),i*(width+dist),&to_string(brick[i][j].exist)[0],255,255,255,255);

                }
                SDL_RenderPresent(renderer);


                bool lost=0,save=0, cont=0;


                ball Ball;
                platformclass platform;
                Ball.damage = damage;

                ball Ball_;
                platformclass platform_;
                Ball_.damage = damage;
                shift(brick,level,hardness);


                jumping:
                platform.yc=SCREEN_HEIGHT-platform.width-64;
                platform.xc=SCREEN_WIDTH/2;

                if(multiplayer){

                    platform.yc=SCREEN_HEIGHT-platform.width-64;
                    platform.xc=SCREEN_WIDTH/4;

                    platform_.yc=SCREEN_HEIGHT-platform_.width-64;
                    platform_.xc=3*SCREEN_WIDTH/4;
                    SDL_SetTextureColorMod(platform_.aks,0,255,184);
                }


                bool jump=0;
                int fireAng =90,fireAng_=90;

                //platform.update(&e);
                SDL_RenderCopy(renderer,background,NULL,NULL);
                platform.render();

                aalineColor(renderer,
                            platform.xc,
                            platform.yc-platform.width/2,
                            platform.xc+50*cos(fireAng*3.14/180),
                            platform.yc-50*sin(fireAng*3.14/180)-platform.width/2,
                            0xffffffff);

                if(multiplayer){

                        platform_.render();

                        aalineColor(renderer,
                            platform_.xc,
                            platform_.yc-platform_.width/2,
                            platform_.xc+50*cos(fireAng_*3.14/180),
                            platform_.yc-50*sin(fireAng_*3.14/180)-platform_.width/2,
                            0xffffffff);
                    }



                SDL_RenderPresent(renderer);

                while(!jump){
                    SDL_Delay(10);
                    //SDL_PollEvent(&e);
                    if(1)
                        {

                        SDL_RenderCopy(renderer,background,NULL,NULL);
                        SDL_PumpEvents();
                        if(keys[SDL_GetScancodeFromKey(SDLK_UP)]) { fireAng++;}
                        else if(keys[SDL_GetScancodeFromKey(SDLK_DOWN)]) {fireAng--;}
                        else if(keys[SDL_GetScancodeFromKey(SDLK_KP_8)]) { fireAng_++;}
                        else if(keys[SDL_GetScancodeFromKey(SDLK_KP_2)]) { fireAng_--;}
                        else if(keys[SDL_GetScancodeFromKey(SDLK_SPACE)]) { jump=1;}
//                        else if(keys[SDL_GetScancodeFromKey(SDLK_y)]){
//
//                            shift(brick,level);
//                            //SDL_SetRenderDrawColor(renderer,0,0,0,0);
//                            //SDL_RenderClear(renderer);
//
//                            for(int i=0;i<10;i++)
//                            for(int j=0;j<8;j++){
//
//                                brick[i][j].render();
//                            }
//                        }




                        //SDL_RenderCopy(renderer,background,NULL,NULL);
                        //SDL_PumpEvents();

                        //platform.multiplater_update(keys,1);
                        platform.multiplater_update(keys,1);
                        platform.render();

                        aalineColor(renderer,
                                    platform.xc,
                                    platform.yc-platform.width/2,
                                    platform.xc+50*cos(fireAng*3.14/180),
                                    platform.yc-50*sin(fireAng*3.14/180)-platform.width/2,
                                    0xff00ffff);



                        if(multiplayer){

                            platform_.multiplater_update(keys,2);
                            platform_.render();
                             aalineColor(renderer,
                                    platform_.xc,
                                    platform_.yc-platform_.width/2,
                                    platform_.xc+50*cos(fireAng_*3.14/180),
                                    platform_.yc-50*sin(fireAng_*3.14/180)-platform_.width/2,
                                    0xffffffff);
                        }
                        for(int i=0;i<10;i++)
                        for(int j=0;j<8;j++){
                            brick[i][j].render();}


                        int w,h;
                        statUpdate(level,score,lives,stat);

                        SDL_QueryTexture(stat,NULL,NULL,&w,&h);
                        SDL_Rect rect={30,SCREEN_HEIGHT-30,w,h};
                        SDL_SetTextureColorMod(stat,0,184,255);
                        SDL_RenderCopy(renderer,stat,NULL,&rect);



                        if(multiplayer){
                            statUpdate(level,score_,lives_,stat_);
                            SDL_QueryTexture(stat_,NULL,NULL,&w,&h);
                            rect={30,SCREEN_HEIGHT-48,w,h};
                             SDL_SetTextureColorMod(stat_,0,255,184);
                            SDL_RenderCopy(renderer,stat_,NULL,&rect);
                        }


                        SDL_RenderPresent(renderer);
                    }


                }
                //ball Ball;
                Ball.yc=platform.yc-platform.width/2-Ball.R;
                Ball.xc=platform.xc;
                Ball.setAng(fireAng);
                if(multiplayer){
                    Ball_.yc=platform_.yc-platform_.width/2-Ball_.R;
                    Ball_.xc=platform_.xc;
                    Ball_.setAng(fireAng_);

                }





                while(!lost && !save && !exi){//each frame happens here
                    contStart:
                    cont = 0;
                    bool stop_menu=1;
                    while(stop_menu){    //SDL_Delay(10);
                         //platform.update(); returns false if ESCAPE key is pressed



                        //////////////////////lost check////////////////////////////////
                       // if(lives<=0 || (lives_<=0 && multiplayer)) {lost = 1; stop_menu=0; if(!multiplayer)save = 1;}
                            for(int j=0;j<8;j++)
                                if(brick[8][j].strength)
                                    {lost = 1; stop_menu=0;
                                    if(!multiplayer)save = 1;}
                        //if(lost)continue;


                        //////////////////////updating objects///////////////////////
                        platform.multiplater_update(keys,1);
                        if(multiplayer)platform_.multiplater_update(keys,2);


                        //if(!platform.update()) break;
                        //SDL_SetRenderDrawColor(renderer,0,0,0,0);
                        //SDL_RenderClear(renderer);
                        SDL_RenderCopy(renderer,background,NULL,NULL);


                        for(int i=0;i<10;i++)
                        for(int j=0;j<8;j++){

                           if(brick[i][j].render()) last_row=i;
                           //stringRGBA(renderer,j*(length+dist),i*(width+dist),&to_string(brick[i][j].strength)[0],255,255,255,255);

                        }

                        Ball.render();
                        platform.render();

                        //cheat code (just for once every live)
                        if(keys[SDL_GetScancodeFromKey(SDLK_c)] &&
                           keys[SDL_GetScancodeFromKey(SDLK_h)] &&
                           keys[SDL_GetScancodeFromKey(SDLK_e)] &&
                           keys[SDL_GetScancodeFromKey(SDLK_a)] &&
                           keys[SDL_GetScancodeFromKey(SDLK_t)] && !cheat_used)
                              {
                                  for(int k=0;k<8;k++)
                                      brick[last_row][k].strength=0;
                                  cheat_used=true;
                              }


                        if(!multiplayer){

                        if(hesoyam_used)
                        {

                                if(keys[SDL_GetScancodeFromKey(SDLK_KP_8)])
                                          {Ball.vy = -abs(Ball.vy);}
                                else if(keys[SDL_GetScancodeFromKey(SDLK_KP_6)])
                                          {Ball.vx = abs(Ball.vx);}
                                else if(keys[SDL_GetScancodeFromKey(SDLK_KP_2)])
                                          {Ball.vy = abs(Ball.vy);}
                                else if(keys[SDL_GetScancodeFromKey(SDLK_KP_4)])
                                          {Ball.vx = -abs(Ball.vx);}
                        }
                        else if(keys[SDL_GetScancodeFromKey(SDLK_h)] &&
                           keys[SDL_GetScancodeFromKey(SDLK_e)] &&
                           keys[SDL_GetScancodeFromKey(SDLK_s)] &&
                           keys[SDL_GetScancodeFromKey(SDLK_o)])

                           {
                                   hesoyam_used=true;

                                   if(keys[SDL_GetScancodeFromKey(SDLK_KP_8)])
                                          {Ball.vy = -abs(Ball.vy);}
                                   else if(keys[SDL_GetScancodeFromKey(SDLK_KP_6)])
                                          {Ball.vx = abs(Ball.vx);}
                                   else if(keys[SDL_GetScancodeFromKey(SDLK_KP_2)])
                                          {Ball.vy = abs(Ball.vy);}
                                   else if(keys[SDL_GetScancodeFromKey(SDLK_KP_4)])
                                          {Ball.vx = -abs(Ball.vx);}

                           } }

                        if(!lost && stop_menu && Ball.update(brick,platform,level,score,lives,stat,cheat_used)){shift(brick,level,hardness); Ball.damage=level; Ball_.damage=level;  goto jumping;}

                        if(multiplayer){

                            Ball_.render();
                            platform_.render();
                            if(!lost && stop_menu && Ball_.update(brick,platform_,level,score_,lives_,stat_,cheat_used)){shift(brick,level,hardness); Ball.damage=level; Ball_.damage=level; goto jumping;}
                        }

                        int w,h;


                        SDL_QueryTexture(stat,NULL,NULL,&w,&h);
                        SDL_Rect rect={30,SCREEN_HEIGHT-30,w,h};
                        SDL_SetTextureColorMod(stat,0,184,255);
                        SDL_RenderCopy(renderer,stat,NULL,&rect);



                        if(multiplayer){
                            SDL_QueryTexture(stat_,NULL,NULL,&w,&h);
                            rect={30,SCREEN_HEIGHT-48,w,h};
                             SDL_SetTextureColorMod(stat_,0,255,184);
                            SDL_RenderCopy(renderer,stat_,NULL,&rect);
                        }



                        SDL_RenderPresent(renderer);

                        SDL_PollEvent(&e);
                        if(e.type == SDL_KEYUP && e.key.keysym.sym== SDLK_ESCAPE){
                            stop_menu = 0;
                            }
                        else if(e.type == SDL_KEYDOWN && e.key.keysym.sym== SDLK_y)
                            {shift(brick,level,hardness);}
//                        else if(e.type == SDL_KEYDOWN && e.key.keysym.sym== SDLK_w)
//                            {Ball.vy = -abs(Ball.vy);}
//                        else if(e.type == SDL_KEYDOWN && e.key.keysym.sym== SDLK_d)
//                            {Ball.vx = abs(Ball.vx);}
//                        else if(e.type == SDL_KEYDOWN && e.key.keysym.sym== SDLK_s)
//                            {Ball.vy = abs(Ball.vy);}
//                        else if(e.type == SDL_KEYDOWN && e.key.keysym.sym== SDLK_a)
//                            {Ball.vx = -abs(Ball.vx);}









                    }


                    Button* save_butt = new Button("Save",SCREEN_WIDTH/2,300);
                    Button* conti = new Button("Continue",SCREEN_WIDTH/2,200);
                    Button* exit = new Button("Exit",SCREEN_WIDTH/2,400);

                    SDL_RenderCopy(renderer,background,NULL,NULL);
                    save_butt->render(0);
                    conti->render(0);
                    exit->render(0);
                    SDL_RenderPresent(renderer);

                    while(!(cont || exi || save) && !lost){


//                        while(e.type != SDL_MOUSEBUTTONDOWN || !(e.type == SDL_KEYDOWN && e.key.keysym.sym == SDLK_ESCAPE))
//                            SDL_PollEvent(&e);
//
//                        while(e.type != SDL_MOUSEBUTTONUP || !(e.type == SDL_KEYUP && e.key.keysym.sym == SDLK_ESCAPE))
//                            SDL_PollEvent(&e);


                        while(e.type != SDL_MOUSEBUTTONDOWN )
                            SDL_PollEvent(&e);

                        while(e.type != SDL_MOUSEBUTTONUP )
                            SDL_PollEvent(&e);

                        //cout << newG->x - newG->w/2 << " < " << e.button.x << " < " << newG->x + newG->w/2 << endl;
                        //cout << newG->y - newG->h/2 << " < " << e.button.y << " < " << newG->y + newG->h/2 << endl;
                        //if(e.type == SDL_MOUSEBUTTONDOWN){
                        if( e.type == SDL_MOUSEBUTTONDOWN || e.type == SDL_MOUSEBUTTONUP ){


                            if(e.button.x < save_butt->x + save_butt->w/2  &&  e.button.x > save_butt->x - save_butt->w/2  &&
                                e.button.y < save_butt->y + save_butt->h/2  &&  e.button.y > save_butt->y - save_butt->h/2)
                                {save = 1; cont = 1;}

                            else if(e.button.x < conti->x + conti->w/2  &&  e.button.x > conti->x - conti->w/2  &&
                                    e.button.y < conti->y + conti->h/2  &&  e.button.y > conti->y - conti->h/2)
                                cont = 1;

                            else if(e.button.x < exit->x + exit->w/2  &&  e.button.x > exit->x - exit->w/2  &&
                                    e.button.y < exit->y + exit->h/2  &&  e.button.y > exit->y - exit->h/2)
                                {exi = 1; save =0;}


                        }



                    }

                }


                if(save && !multiplayer){  //saving the brick data

                    save=0;
                    string::size_type index = brickData.find(Name);

                    if(index == string::npos){  //saving for new user
                        brickData += "\n" + Name + "d>" + to_string(Ball.damage);


                        for(int i=0;i<10;i++)
                        for(int j=0; j<8;j++){

                            brickData += "/" + to_string(brick[i][j].strength) + "-" + to_string(brick[i][j].first_strength) ;

                        }
                        brickData += "/" ;

                        //cout<< brickData;


                    }else{     //saving for old user


                        string append = to_string(Ball.damage);
                        for(int i=0;i<10;i++)
                        for(int j=0; j<8;j++){

                            append += "/" + to_string(brick[i][j].strength) + "-" + to_string(brick[i][j].first_strength) ;

                        }
                        append += "/" ;
                        int replaceBegin = brickData.find( ">", brickData.find(Name))+1;
                        int replaceEnd =    brickData.find( '\n', brickData.find(Name))-1;
                        brickData.replace( replaceBegin , replaceEnd - replaceBegin +1 , append );
                    }
                    bricks.open("brick.txt",ios_base::out|ios_base::trunc);
                    bricks << brickData;
                    bricks.close();



                    if(!isNew){
                        string append = Name + "c>";
                        append += (my->recordCount == 5? "5" : to_string(my->recordCount+1)) + "</c>";

                        append += "<lev>" + to_string(level) + "</lev>"
                                    + "<s>" + to_string(score) + "</s>"
                                    + "<liv>" + to_string(lives) + "</liv>";

                        for(
                            int i = 0 ;
                            i < (my->recordCount == 5 ? 4 : my->recordCount)  ;
                            i++)

                                {
                            append += "\n" ;
                            append += "<lev>" + to_string(my->levels[i]) + "</lev>"
                                    + "<s>" + to_string(my->scores[i]) + "</s>"
                                    + "<liv>" + to_string(my->lives[i]) + "</liv>";
                        }
                        append += "%";
                        int replaceBegin = saves.find(Name);
                        int replaceEnd = saves.find('%', replaceBegin+1);// -2 is for @ and '\n'
                        saves.replace( replaceBegin , replaceEnd - replaceBegin +1 , append );
                    }else{
                        saves += "\n" + Name + "c>1</c>";


                        saves += "<lev>" + to_string(level) + "</lev>"
                                    + "<s>" + to_string(score) + "</s>"
                                    + "<liv>" + to_string(lives) + "</liv>%";


                    }

                    out.open("saves.txt",ios_base::out|ios_base::trunc);
                    out << saves;
                    out.close();
                }
                if(cont) {
                        cont =0;
                        goto contStart;}
                if(exi) {quit = 1;}

                if(lost){
                    if(enem){


                        if(score>score_){
                            SDL_Color col = {0,184,255,255}; gTempSurface = TTF_RenderText_Solid(gFont,"BLUE WON",col);}
                        else if(score==score_){
                            SDL_Color col = {255,255,255,255}; gTempSurface = TTF_RenderText_Solid(gFont,"DRAW",col);}
                        else{
                            SDL_Color col = {0,255,184,255}; gTempSurface = TTF_RenderText_Solid(gFont,"GREEN WON",col);}

                        gTempTexture = SDL_CreateTextureFromSurface(renderer,gTempSurface);
                        int w,h;
                        SDL_QueryTexture(gTempTexture,NULL,NULL,&w,&h);
                        background = IMG_LoadTexture(renderer,"xx1.jpg");
                        SDL_RenderCopy(renderer,background,NULL,NULL);
                        SDL_Rect x={SCREEN_WIDTH/2-w/2,SCREEN_HEIGHT/2-h/2,w,h};
                        SDL_RenderCopy(renderer,gTempTexture,NULL,&x);
                        SDL_RenderPresent(renderer);
                        SDL_Delay(4000);
                        enem = 0;


                       }
                    else if(frien){


//                        if(score>score_){
//                            SDL_Color col = {0,184,255,255}; gTempSurface = TTF_RenderText_Solid(gFont,"BLUE WON",col);}
//                        else if(score=score_){
//                            SDL_Color col = {0,184,184}; gTempSurface = TTF_RenderText_Solid(gFont,"DRAW",col);}
//                        else{
//                            SDL_Color col = {0,255,184}; gTempSurface = TTF_RenderText_Solid(gFont,"GREEN WON",col);}
                        SDL_Color col = {255,255,255,255};
                        string text = "You scored "+ to_string(score+score_) + " in total.";
                        gTempSurface = TTF_RenderText_Solid(gFont,&text[0],col);
                        gTempTexture = SDL_CreateTextureFromSurface(renderer,gTempSurface);
                        int w,h;
                        SDL_QueryTexture(gTempTexture,NULL,NULL,&w,&h);
                        background = IMG_LoadTexture(renderer,"xx1.jpg");
                        SDL_RenderCopy(renderer,background,NULL,NULL);
                        SDL_Rect x={SCREEN_WIDTH/2-w/2,SCREEN_HEIGHT/2-h/2,w,h};
                        SDL_RenderCopy(renderer,gTempTexture,NULL,&x);
                        SDL_RenderPresent(renderer);
                        SDL_Delay(4000);
                        frien = 0;

                    }
                    else if(newGflag || loadflag){


//                        if(score>score_){
//                            SDL_Color col = {0,184,255,255}; gTempSurface = TTF_RenderText_Solid(gFont,"BLUE WON",col);}
//                        else if(score=score_){
//                            SDL_Color col = {0,184,184}; gTempSurface = TTF_RenderText_Solid(gFont,"DRAW",col);}
//                        else{
//                            SDL_Color col = {0,255,184}; gTempSurface = TTF_RenderText_Solid(gFont,"GREEN WON",col);}
                        SDL_Color col = {255,255,255,255};
                        string text = "You lost!";
                        gTempSurface = TTF_RenderText_Solid(gFont,&text[0],col);
                        gTempTexture = SDL_CreateTextureFromSurface(renderer,gTempSurface);
                        int w,h;
                        SDL_QueryTexture(gTempTexture,NULL,NULL,&w,&h);
                        background = IMG_LoadTexture(renderer,"xx1.jpg");
                        SDL_RenderCopy(renderer,background,NULL,NULL);
                        SDL_Rect x={SCREEN_WIDTH/2-w/2,SCREEN_HEIGHT/2-h/2,w,h};
                        SDL_RenderCopy(renderer,gTempTexture,NULL,&x);
                        SDL_RenderPresent(renderer);
                        SDL_Delay(4000);
                        newGflag = 0;
                        loadflag = 0;

                    }


                    Mix_PlayMusic(main_music,1);
                    goto cc;  //////////////////////////


                }



            }
            else if(e.type == SDL_KEYDOWN){//filling the textbox
                cc:
                SDL_RenderCopy(renderer,background,NULL,NULL);

                int r,g,b;
                randomCol(r,g,b);
                SDL_SetTextureColorMod(name->aks,r,g,b);  //range random baraye textbox

                name->addText(e);

            }
            //cout << name->text<<'.'<<endl;


        }

				//Apply the imag
	}

	//Free resources and close SDL
	close();

	return 0;
}


/**  ////////////////////
*    init func //////////
*    ////////////////////
*
*/

bool init()
{
    //Initialization flag
    bool success = true;

    //Initialize SDL
    if( SDL_Init( SDL_INIT_VIDEO ) < 0 )
    {
        printf( "SDL could not initialize! SDL_Error: %s\n", SDL_GetError() );
        success = false;
    }
    else
    {
        //Create window
        gWindow = SDL_CreateWindow( "SDL Tutorial", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN );
        if( gWindow == NULL )
        {
            printf( "Window could not be created! SDL_Error: %s\n", SDL_GetError() );
            success = false;
        }
        else
        {
            //Get window surface
            //gScreenSurface = SDL_GetWindowSurface( gWindow );
        }
        //SDL_SetWindowFullscreen(gWindow, SDL_WINDOW_FULLSCREEN_DESKTOP);
        //SDL_GetWindowSize(gWindow,&SCREEN_WIDTH,&SCREEN_HEIGHT);
        renderer = SDL_CreateRenderer(gWindow,-1,SDL_RENDERER_SOFTWARE);
    }

    return success;
}

/**  ////////////////////
*    media func /////////
*    ////////////////////
*
*/

bool loadMedia()
{
    //Loading success flag
    bool success = true;

    //Load splash image
    SDL_SetRenderTarget(renderer,gTempTexture);
    //gTempSurface = SDL_LoadBMP("content/car.bmp");
    gTempTexture = IMG_LoadTexture(renderer,"content/car.bmp");
    SDL_RenderCopy(renderer,gTempTexture,NULL,NULL);
    SDL_SetRenderDrawColor(renderer, 255, 255, 255,255);
    lineColor(renderer,100,100,200,200,0xff0000ff);

    //SDL_RenderDrawLine(renderer,100,110,200,210);
    rectangleColor(renderer,100,100,200,200,0xff0000ff);
    SDL_RenderPresent(renderer);


    return success;
}


/**  ////////////////////
*    close func /////////
*    ////////////////////
*
*/

void close()
{
    //Deallocate surface
//    SDL_FreeSurface( gHelloWorld );
//    gHelloWorld = NULL;
//    SDL_FreeSurface( gTempSurface );
//    gTempSurface = NULL;
    SDL_DestroyTexture( gTempTexture);
    SDL_DestroyTexture( nameMenu);
    SDL_DestroyTexture( brickPhoto100);
    SDL_DestroyTexture( brickPhoto75);
    SDL_DestroyTexture( brickPhoto50);
    SDL_DestroyTexture( brickPhoto25);
    SDL_DestroyTexture( brickPhoto0);
    SDL_DestroyTexture(levelTex);
    SDL_DestroyTexture(scoreTex);
    SDL_DestroyTexture(livTex);
    SDL_DestroyTexture(hardnes);

    //SDL_DestroyTexture( brickPhoto25);


    SDL_DestroyRenderer(renderer);
    renderer = NULL;
    //Destroy window
    SDL_DestroyWindow( gWindow );
    gWindow = NULL;
    //Mix_CloseAudio();
    Mix_FreeChunk(music);
    Mix_FreeMusic(main_music);
    Mix_FreeMusic(misic);
    Mix_Quit();
    IMG_Quit();
    //Quit SDL subsystems
    SDL_Quit();
    printf("done");
}



